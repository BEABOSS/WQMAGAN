from os import path as osp
from osgeo import gdal
from basicsr.utils import scandir


def generate_meta_info_tif():
    """Generate meta info for TIF format remote sensing dataset."""
    
    gt_folder = r"D:\Code\BasicSR-master\BasicSR-master\AID Data Set\Industrial"
    meta_info_txt = r"D:\Code\BasicSR-master\BasicSR-master\basicsr\data\meta_info\industrial_meta_info.txt"

    img_list = sorted(list(scandir(gt_folder, suffix='jpg', recursive=False)))

    with open(meta_info_txt, 'w') as f:
        for idx, img_path in enumerate(img_list):
            img_full_path = osp.join(gt_folder, img_path)
            dataset = gdal.Open(img_full_path)
            if dataset is None:
                print(f"Warning: Failed to open {img_full_path}")
                continue
            
            width = dataset.RasterXSize
            height = dataset.RasterYSize
            n_channel = dataset.RasterCount

            info = f'{img_path} ({height},{width},{n_channel})'
            print(idx + 1, info)
            f.write(f'{info}\n')


if __name__ == '__main__':
    generate_meta_info_tif()

