# GENERATED VERSION FILE
# TIME: Wed Apr 16 15:30:00 2025
__version__ = '1.4.2'
__gitsha__ = 'unknown'
version_info = (1, 4, 2)
