# import torch
# from collections import OrderedDict
# from os import path as osp
# from tqdm import tqdm

# from basicsr.archs import build_network
# from basicsr.losses import build_loss
# from basicsr.metrics import calculate_metric
# from basicsr.utils import get_root_logger, imwrite, tensor2img
# from basicsr.utils.registry import MODEL_REGISTRY
# from .base_model import BaseModel


# @MODEL_REGISTRY.register()
# class SRModel(BaseModel):
#     """Base SR model for single image super-resolution."""

#     def __init__(self, opt):
#         super(SRModel, self).__init__(opt)

#         # define network
#         self.net_g = build_network(opt['network_g'])
#         self.net_g = self.model_to_device(self.net_g)
#         self.print_network(self.net_g)

#         # load pretrained models
#         load_path = self.opt['path'].get('pretrain_network_g', None)
#         if load_path is not None:
#             param_key = self.opt['path'].get('param_key_g', 'params')
#             self.load_network(self.net_g, load_path, self.opt['path'].get('strict_load_g', True), param_key)

#         if self.is_train:
#             self.init_training_settings()

#     def init_training_settings(self):
#         self.net_g.train()
#         train_opt = self.opt['train']

#         self.ema_decay = train_opt.get('ema_decay', 0)
#         if self.ema_decay > 0:
#             logger = get_root_logger()
#             logger.info(f'Use Exponential Moving Average with decay: {self.ema_decay}')
#             # define network net_g with Exponential Moving Average (EMA)
#             # net_g_ema is used only for testing on one GPU and saving
#             # There is no need to wrap with DistributedDataParallel
#             self.net_g_ema = build_network(self.opt['network_g']).to(self.device)
#             # load pretrained model
#             load_path = self.opt['path'].get('pretrain_network_g', None)
#             if load_path is not None:
#                 self.load_network(self.net_g_ema, load_path, self.opt['path'].get('strict_load_g', True), 'params_ema')
#             else:
#                 self.model_ema(0)  # copy net_g weight
#             self.net_g_ema.eval()

#         # define losses
#         if train_opt.get('pixel_opt'):
#             self.cri_pix = build_loss(train_opt['pixel_opt']).to(self.device)
#         else:
#             self.cri_pix = None

#         if train_opt.get('perceptual_opt'):
#             self.cri_perceptual = build_loss(train_opt['perceptual_opt']).to(self.device)
#         else:
#             self.cri_perceptual = None

#         # 添加 wavelet 损失
#         if train_opt.get('wavelet_opt'):
#             self.cri_wavelet = build_loss(train_opt['wavelet_opt']).to(self.device)
#         else:
#             self.cri_wavelet = None

#         # 添加 WeightedTVLoss
#         if train_opt.get('tv_opt'):
#             self.cri_tv = build_loss(train_opt['tv_opt']).to(self.device)
#         else:
#             self.cri_tv = None

#         # 添加 SAMLoss
#         if train_opt.get('sam_opt'):
#             self.cri_sam = build_loss(train_opt['sam_opt']).to(self.device)
#         else:
#             self.cri_sam = None
            
#         # 添加 EdgeLoss
#         if train_opt.get('edge_opt'):
#             self.cri_edge = build_loss(train_opt['edge_opt']).to(self.device)
#         else:
#             self.cri_edge = None

#         if self.cri_pix is None and self.cri_perceptual is None and self.cri_wavelet is None:
#             raise ValueError('All losses (pixel, perceptual, wavelet) are None.')

#         # set up optimizers and schedulers
#         self.setup_optimizers()
#         self.setup_schedulers()

#     def setup_optimizers(self):
#         train_opt = self.opt['train']
#         optim_params = []
#         for k, v in self.net_g.named_parameters():
#             if v.requires_grad:
#                 optim_params.append(v)
#             else:
#                 logger = get_root_logger()
#                 logger.warning(f'Params {k} will not be optimized.')

#         optim_type = train_opt['optim_g'].pop('type')
#         self.optimizer_g = self.get_optimizer(optim_type, optim_params, **train_opt['optim_g'])
#         self.optimizers.append(self.optimizer_g)

#     def feed_data(self, data):
#         self.lq = data['lq'].to(self.device)
#         if 'gt' in data:
#             self.gt = data['gt'].to(self.device)

#     def optimize_parameters(self, current_iter):
#         self.optimizer_g.zero_grad()
#         self.output = self.net_g(self.lq)

#         l_total = 0
#         loss_dict = OrderedDict()
#         # pixel loss
#         if self.cri_pix:
#             l_pix = self.cri_pix(self.output, self.gt)
#             l_total += l_pix
#             loss_dict['l_pix'] = l_pix
#         # perceptual loss
#         if self.cri_perceptual:
#             l_percep, l_style = self.cri_perceptual(self.output, self.gt)
#             if l_percep is not None:
#                 l_total += l_percep
#                 loss_dict['l_percep'] = l_percep
#             if l_style is not None:
#                 l_total += l_style
#                 loss_dict['l_style'] = l_style
#         # wavelet loss
#         if self.cri_wavelet:
#             l_wavelet = self.cri_wavelet(self.output, self.gt)
#             l_total += l_wavelet
#             loss_dict['l_wavelet'] = l_wavelet
        
#         # EdgeLoss
#         if self.cri_edge:
#             l_edge = self.cri_edge(self.output, self.gt)
#             l_total += l_edge
#             loss_dict['l_edge'] = l_edge

#         l_total.backward()
#         self.optimizer_g.step()

#         self.log_dict = self.reduce_loss_dict(loss_dict)

#         if self.ema_decay > 0:
#             self.model_ema(decay=self.ema_decay)

#     def test(self):
#         if hasattr(self, 'net_g_ema'):
#             self.net_g_ema.eval()
#             with torch.no_grad():
#                 self.output = self.net_g_ema(self.lq)
#         else:
#             self.net_g.eval()
#             with torch.no_grad():
#                 self.output = self.net_g(self.lq)
#             self.net_g.train()

#     def test_selfensemble(self):
#         # TODO: to be tested
#         # 8 augmentations
#         # modified from https://github.com/thstkdgus35/EDSR-PyTorch

#         def _transform(v, op):
#             # if self.precision != 'single': v = v.float()
#             v2np = v.data.cpu().numpy()
#             if op == 'v':
#                 tfnp = v2np[:, :, :, ::-1].copy()
#             elif op == 'h':
#                 tfnp = v2np[:, :, ::-1, :].copy()
#             elif op == 't':
#                 tfnp = v2np.transpose((0, 1, 3, 2)).copy()

#             ret = torch.Tensor(tfnp).to(self.device)
#             # if self.precision == 'half': ret = ret.half()

#             return ret

#         # prepare augmented data
#         lq_list = [self.lq]
#         for tf in 'v', 'h', 't':
#             lq_list.extend([_transform(t, tf) for t in lq_list])

#         # inference
#         if hasattr(self, 'net_g_ema'):
#             self.net_g_ema.eval()
#             with torch.no_grad():
#                 out_list = [self.net_g_ema(aug) for aug in lq_list]
#         else:
#             self.net_g.eval()
#             with torch.no_grad():
#                 out_list = [self.net_g_ema(aug) for aug in lq_list]
#             self.net_g.train()

#         # merge results
#         for i in range(len(out_list)):
#             if i > 3:
#                 out_list[i] = _transform(out_list[i], 't')
#             if i % 4 > 1:
#                 out_list[i] = _transform(out_list[i], 'h')
#             if (i % 4) % 2 == 1:
#                 out_list[i] = _transform(out_list[i], 'v')
#         output = torch.cat(out_list, dim=0)

#         self.output = output.mean(dim=0, keepdim=True)

#     def dist_validation(self, dataloader, current_iter, tb_logger, save_img):
#         if self.opt['rank'] == 0:
#             self.nondist_validation(dataloader, current_iter, tb_logger, save_img)

#     def nondist_validation(self, dataloader, current_iter, tb_logger, save_img):
#         dataset_name = dataloader.dataset.opt['name']
#         with_metrics = self.opt['val'].get('metrics') is not None
#         use_pbar = self.opt['val'].get('pbar', False)

#         if with_metrics:
#             if not hasattr(self, 'metric_results'):  # only execute in the first run
#                 self.metric_results = {metric: 0 for metric in self.opt['val']['metrics'].keys()}
#             # initialize the best metric results for each dataset_name (supporting multiple validation datasets)
#             self._initialize_best_metric_results(dataset_name)
#         # zero self.metric_results
#         if with_metrics:
#             self.metric_results = {metric: 0 for metric in self.metric_results}

#         metric_data = dict()
#         if use_pbar:
#             pbar = tqdm(total=len(dataloader), unit='image')

#         for idx, val_data in enumerate(dataloader):
#             img_name = osp.splitext(osp.basename(val_data['lq_path'][0]))[0]
#             self.feed_data(val_data)
#             self.test()

#             visuals = self.get_current_visuals()
#             sr_img = tensor2img([visuals['result']])
#             metric_data['img'] = sr_img
#             if 'gt' in visuals:
#                 gt_img = tensor2img([visuals['gt']])
#                 metric_data['img2'] = gt_img
#                 del self.gt

#             # tentative for out of GPU memory
#             del self.lq
#             del self.output
#             torch.cuda.empty_cache()

#             if save_img:
#                 if self.opt['is_train']:
#                     save_img_path = osp.join(self.opt['path']['visualization'], img_name,
#                                              f'{img_name}_{current_iter}.png')
#                 else:
#                     if self.opt['val']['suffix']:
#                         save_img_path = osp.join(self.opt['path']['visualization'], dataset_name,
#                                                  f'{img_name}_{self.opt["val"]["suffix"]}.png')
#                     else:
#                         save_img_path = osp.join(self.opt['path']['visualization'], dataset_name,
#                                                  f'{img_name}_{self.opt["name"]}.png')
#                 imwrite(sr_img, save_img_path)

#             if with_metrics:
#                 # calculate metrics
#                 for name, opt_ in self.opt['val']['metrics'].items():
#                     self.metric_results[name] += calculate_metric(metric_data, opt_)
#             if use_pbar:
#                 pbar.update(1)
#                 pbar.set_description(f'Test {img_name}')
#         if use_pbar:
#             pbar.close()

#         if with_metrics:
#             for metric in self.metric_results.keys():
#                 self.metric_results[metric] /= (idx + 1)
#                 # update the best metric result
#                 self._update_best_metric_result(dataset_name, metric, self.metric_results[metric], current_iter)

#             self._log_validation_metric_values(current_iter, dataset_name, tb_logger)

#     def _log_validation_metric_values(self, current_iter, dataset_name, tb_logger):
#         log_str = f'Validation {dataset_name}\n'
#         for metric, value in self.metric_results.items():
#             log_str += f'\t # {metric}: {value:.4f}'
#             if hasattr(self, 'best_metric_results'):
#                 log_str += (f'\tBest: {self.best_metric_results[dataset_name][metric]["val"]:.4f} @ '
#                             f'{self.best_metric_results[dataset_name][metric]["iter"]} iter')
#             log_str += '\n'

#         logger = get_root_logger()
#         logger.info(log_str)
#         if tb_logger:
#             for metric, value in self.metric_results.items():
#                 tb_logger.add_scalar(f'metrics/{dataset_name}/{metric}', value, current_iter)

#     def get_current_visuals(self):
#         out_dict = OrderedDict()
#         out_dict['lq'] = self.lq.detach().cpu()
#         out_dict['result'] = self.output.detach().cpu()
#         if hasattr(self, 'gt'):
#             out_dict['gt'] = self.gt.detach().cpu()
#         return out_dict

#     def save(self, epoch, current_iter):
#         if hasattr(self, 'net_g_ema'):
#             self.save_network([self.net_g, self.net_g_ema], 'net_g', current_iter, param_key=['params', 'params_ema'])
#         else:
#             self.save_network(self.net_g, 'net_g', current_iter)
#         self.save_training_state(epoch, current_iter)


import torch
from collections import OrderedDict
from os import path as osp
from tqdm import tqdm
import torch.nn.functional as F

from basicsr.archs import build_network
from basicsr.losses import build_loss
from basicsr.metrics import calculate_metric
from basicsr.utils import get_root_logger, imwrite, tensor2img
from basicsr.utils.registry import MODEL_REGISTRY
from .base_model import BaseModel


@MODEL_REGISTRY.register()
class SRModel(BaseModel):
    """Base SR model for single image super-resolution."""

    def __init__(self, opt):
        super(SRModel, self).__init__(opt)

        # define network
        self.net_g = build_network(opt['network_g'])
        self.net_g = self.model_to_device(self.net_g)
        self.print_network(self.net_g)

        # load pretrained models
        load_path = self.opt['path'].get('pretrain_network_g', None)
        if load_path is not None:
            param_key = self.opt['path'].get('param_key_g', 'params')
            self.load_network(self.net_g, load_path, self.opt['path'].get('strict_load_g', True), param_key)

        if self.is_train:
            self.init_training_settings()

    def init_training_settings(self):
        self.net_g.train()
        train_opt = self.opt['train']

        self.ema_decay = train_opt.get('ema_decay', 0)
        if self.ema_decay > 0:
            logger = get_root_logger()
            logger.info(f'Use Exponential Moving Average with decay: {self.ema_decay}')
            # net_g_ema is used only for testing on one GPU and saving
            self.net_g_ema = build_network(self.opt['network_g']).to(self.device)
            # load pretrained model
            load_path = self.opt['path'].get('pretrain_network_g', None)
            if load_path is not None:
                self.load_network(self.net_g_ema, load_path, self.opt['path'].get('strict_load_g', True), 'params_ema')
            else:
                self.model_ema(0)  # copy net_g weight
            self.net_g_ema.eval()

        # define losses
        if train_opt.get('pixel_opt'):
            self.cri_pix = build_loss(train_opt['pixel_opt']).to(self.device)
        else:
            self.cri_pix = None

        if train_opt.get('perceptual_opt'):
            self.cri_perceptual = build_loss(train_opt['perceptual_opt']).to(self.device)
        else:
            self.cri_perceptual = None

        # 添加 wavelet 损失
        if train_opt.get('wavelet_opt'):
            self.cri_wavelet = build_loss(train_opt['wavelet_opt']).to(self.device)
        else:
            self.cri_wavelet = None

        # 添加 WeightedTVLoss
        if train_opt.get('tv_opt'):
            self.cri_tv = build_loss(train_opt['tv_opt']).to(self.device)
        else:
            self.cri_tv = None

        # 添加 SAMLoss
        if train_opt.get('sam_opt'):
            self.cri_sam = build_loss(train_opt['sam_opt']).to(self.device)
        else:
            self.cri_sam = None

        # 添加 EdgeLoss
        if train_opt.get('edge_opt'):
            self.cri_edge = build_loss(train_opt['edge_opt']).to(self.device)
        else:
            self.cri_edge = None

        if self.cri_pix is None and self.cri_perceptual is None and self.cri_wavelet is None:
            raise ValueError('All losses (pixel, perceptual, wavelet) are None.')

        # set up optimizers and schedulers
        self.setup_optimizers()
        self.setup_schedulers()

    def setup_optimizers(self):
        train_opt = self.opt['train']
        optim_params = []
        for k, v in self.net_g.named_parameters():
            if v.requires_grad:
                optim_params.append(v)
            else:
                logger = get_root_logger()
                logger.warning(f'Params {k} will not be optimized.')

        optim_type = train_opt['optim_g'].pop('type')
        self.optimizer_g = self.get_optimizer(optim_type, optim_params, **train_opt['optim_g'])
        self.optimizers.append(self.optimizer_g)

    def feed_data(self, data):
        """Feed a batch (lq, gt maybe) to model and record original sizes for later cropping."""
        self.lq = data['lq'].to(self.device)
        # record original LQ size for later cropping in validation
        _, _, h_lq, w_lq = self.lq.shape
        self._orig_size_lq = (h_lq, w_lq)

        if 'gt' in data:
            self.gt = data['gt'].to(self.device)
            _, _, h_gt, w_gt = self.gt.shape
            self._orig_size_gt = (h_gt, w_gt)
        else:
            self._orig_size_gt = None

    def optimize_parameters(self, current_iter):
        self.optimizer_g.zero_grad()
        self.output = self.net_g(self.lq)

        l_total = 0
        loss_dict = OrderedDict()
        # pixel loss
        if self.cri_pix:
            l_pix = self.cri_pix(self.output, self.gt)
            l_total += l_pix
            loss_dict['l_pix'] = l_pix
        # perceptual loss
        if self.cri_perceptual:
            l_percep, l_style = self.cri_perceptual(self.output, self.gt)
            if l_percep is not None:
                l_total += l_percep
                loss_dict['l_percep'] = l_percep
            if l_style is not None:
                l_total += l_style
                loss_dict['l_style'] = l_style
        # wavelet loss
        if self.cri_wavelet:
            l_wavelet = self.cri_wavelet(self.output, self.gt)
            l_total += l_wavelet
            loss_dict['l_wavelet'] = l_wavelet

        # EdgeLoss
        if self.cri_edge:
            l_edge = self.cri_edge(self.output, self.gt)
            l_total += l_edge
            loss_dict['l_edge'] = l_edge

        l_total.backward()
        self.optimizer_g.step()

        self.log_dict = self.reduce_loss_dict(loss_dict)

        if self.ema_decay > 0:
            self.model_ema(decay=self.ema_decay)

    def test(self):
        if hasattr(self, 'net_g_ema'):
            self.net_g_ema.eval()
            with torch.no_grad():
                self.output = self.net_g_ema(self.lq)
        else:
            self.net_g.eval()
            with torch.no_grad():
                self.output = self.net_g(self.lq)
            self.net_g.train()

    def test_selfensemble(self):
        # TODO: to be tested
        # 8 augmentations
        # modified from https://github.com/thstkdgus35/EDSR-PyTorch

        def _transform(v, op):
            # if self.precision != 'single': v = v.float()
            v2np = v.data.cpu().numpy()
            if op == 'v':
                tfnp = v2np[:, :, :, ::-1].copy()
            elif op == 'h':
                tfnp = v2np[:, :, ::-1, :].copy()
            elif op == 't':
                tfnp = v2np.transpose((0, 1, 3, 2)).copy()

            ret = torch.Tensor(tfnp).to(self.device)
            # if self.precision == 'half': ret = ret.half()

            return ret

        # prepare augmented data
        lq_list = [self.lq]
        for tf in 'v', 'h', 't':
            lq_list.extend([_transform(t, tf) for t in lq_list])

        # inference
        if hasattr(self, 'net_g_ema'):
            self.net_g_ema.eval()
            with torch.no_grad():
                out_list = [self.net_g_ema(aug) for aug in lq_list]
        else:
            self.net_g.eval()
            with torch.no_grad():
                out_list = [self.net_g_ema(aug) for aug in lq_list]
            self.net_g.train()

        # merge results
        for i in range(len(out_list)):
            if i > 3:
                out_list[i] = _transform(out_list[i], 't')
            if i % 4 > 1:
                out_list[i] = _transform(out_list[i], 'h')
            if (i % 4) % 2 == 1:
                out_list[i] = _transform(out_list[i], 'v')
        output = torch.cat(out_list, dim=0)

        self.output = output.mean(dim=0, keepdim=True)

    def dist_validation(self, dataloader, current_iter, tb_logger, save_img):
        if self.opt.get('rank', 0) == 0:
            self.nondist_validation(dataloader, current_iter, tb_logger, save_img)

    # ----------------- 辅助函数：推断补齐基数 -----------------
    def _infer_padding_base(self, fallback=8):
        """
        尝试从 self.net_g 模块中自动推断需要补齐到的最小倍数（patch/window/kernel/scale 等）。
        如果找不到任何线索则返回 fallback（默认为 8）。
        """
        # 1) 尝试模型根属性
        candidates = []
        for attr in ('patch_size', 'window_size', 'patches', 'kernel_size', 'scale', 'stride'):
            if hasattr(self.net_g, attr):
                val = getattr(self.net_g, attr)
                try:
                    # 如果是 int 或可转换为 int
                    candidates.append(int(val))
                except Exception:
                    pass

        # 2) 遍历子模块尝试找属性
        for m in self.net_g.modules():
            for attr in ('patch_size', 'window_size', 'kernel_size', 'stride'):
                if hasattr(m, attr):
                    val = getattr(m, attr)
                    try:
                        candidates.append(int(val))
                    except Exception:
                        pass
            # 如果模块是卷积层，尝试读取 kernel_size（可能为 tuple）
            if hasattr(m, 'kernel_size'):
                ks = getattr(m, 'kernel_size')
                if isinstance(ks, tuple):
                    candidates.append(int(ks[0]))
                else:
                    try:
                        candidates.append(int(ks))
                    except Exception:
                        pass

        # 3) 过滤并选择合适的基数（取最大公约数或最小有意义值）
        candidates = [c for c in candidates if isinstance(c, int) and c > 0]
        if len(candidates) == 0:
            return fallback

        # 选一个合理的 base：通常取 candidates 中的最大值的因子或直接最大值的最小幂次因子
        # 这里我们选择 candidates 的最大值并将其限制到 2 的幂或常见值
        cand = max(candidates)
        # 合理化 cand：如果 cand 为偶数，使用 cand；否则回退到 8
        if cand >= 2 and cand <= 64:
            return cand
        return fallback

    def _pad_to_multiple(self, x, base=8):
        """对张量 x 补齐到 base 的倍数（右、下方向 pad），返回 pad 后张量和 pad 大小 (pad_h, pad_w)。"""
        _, _, h, w = x.size()
        pad_h = (base - h % base) % base
        pad_w = (base - w % base) % base
        if pad_h > 0 or pad_w > 0:
            x = F.pad(x, (0, pad_w, 0, pad_h), mode='reflect')
        return x, (pad_h, pad_w)

    def _crop_to_origin(self, img, orig_size):
        """将 numpy 或 PIL 形式的图像裁回原始尺寸。如果传入 tensor 形式（C,H,W）则也可处理。"""
        # img 是 numpy array HxWxC 或 CxHxW（tensor2img 返回的是 numpy HxWxC）
        # 这里假设 img 为 numpy HxWxC
        h0, w0 = orig_size
        if img.shape[0] == h0 and img.shape[1] == w0:
            return img
        return img[:h0, :w0, ...]  # 裁剪下、右方向的填充

    # ----------------- 修改后的非分布式验证 -----------------
    def nondist_validation(self, dataloader, current_iter, tb_logger, save_img):
        """
        非分布式验证。
        - 自动推断 pad 基数（尽可能基于网络结构）
        - 对 lq/gt 进行反射填充到 base 的倍数
        - 推理后将输出裁回原始尺寸再保存/计算度量
        """
        dataset_name = dataloader.dataset.opt['name']
        with_metrics = self.opt['val'].get('metrics') is not None
        use_pbar = self.opt['val'].get('pbar', False)

        if with_metrics:
            if not hasattr(self, 'metric_results'):  # only execute in the first run
                self.metric_results = {metric: 0 for metric in self.opt['val']['metrics'].keys()}
            # initialize the best metric results for each dataset_name (supporting multiple validation datasets)
            self._initialize_best_metric_results(dataset_name)
        # zero self.metric_results
        if with_metrics:
            self.metric_results = {metric: 0 for metric in self.metric_results}

        # 推断 pad 基数（尽量动态）
        pad_base = self._infer_padding_base(fallback=8)
        logger = get_root_logger()
        logger.info(f'Validation: inferred pad base = {pad_base}')

        metric_data = dict()
        if use_pbar:
            pbar = tqdm(total=len(dataloader), unit='image')

        for idx, val_data in enumerate(dataloader):
            img_name = osp.splitext(osp.basename(val_data['lq_path'][0]))[0]
            # feed and record original sizes inside feed_data()
            self.feed_data(val_data)

            # pad lq / gt 到 pad_base 的倍数
            self.lq, (pad_h_lq, pad_w_lq) = self._pad_to_multiple(self.lq, base=pad_base)
            if hasattr(self, 'gt') and self.gt is not None:
                self.gt, (pad_h_gt, pad_w_gt) = self._pad_to_multiple(self.gt, base=pad_base)
            else:
                pad_h_gt, pad_w_gt = 0, 0

            # 推理
            self.test()

            # 获取可视化图像（numpy HxWxC）
            visuals = self.get_current_visuals()
            sr_img = tensor2img([visuals['result']])  # numpy HxWxC
            metric_data['img'] = sr_img

            if 'gt' in visuals:
                gt_img = tensor2img([visuals['gt']])
                # 裁回原始 GT 尺寸（避免 pad 影响度量）
                if hasattr(self, '_orig_size_gt') and self._orig_size_gt is not None:
                    gt_img = self._crop_to_origin(gt_img, self._orig_size_gt)
                metric_data['img2'] = gt_img
                del self.gt

            # 裁回原始 LQ / 输出尺寸（输出为 sr_img）
            if hasattr(self, '_orig_size_lq') and self._orig_size_lq is not None:
                # 生成器输出尺寸通常是 scale 倍，如果你想裁回到 LQ 的原始尺寸需考虑 scale。
                # 但我们这里假设你想把 SR 裁回到与 GT 一样的尺寸（如果 GT 存在）。
                if 'img2' in metric_data:
                    # 如果有 GT，就裁回 GT 大小
                    sr_img = self._crop_to_origin(sr_img, metric_data['img2'].shape[:2])
                else:
                    # 否则裁回 LQ 的原始大小（注意：SR 与 LQ 可能尺度不同）
                    sr_img = self._crop_to_origin(sr_img, self._orig_size_lq)

            metric_data['img'] = sr_img

            # free GPU memory
            del self.lq
            del self.output
            torch.cuda.empty_cache()

            # save image (用裁回后的 sr_img)
            if save_img:
                if self.opt.get('is_train', False):
                    save_img_path = osp.join(self.opt['path']['visualization'], img_name,
                                             f'{img_name}_{current_iter}.png')
                else:
                    if self.opt['val'].get('suffix', ''):
                        save_img_path = osp.join(self.opt['path']['visualization'], dataset_name,
                                                 f'{img_name}_{self.opt["val"]["suffix"]}.png')
                    else:
                        save_img_path = osp.join(self.opt['path']['visualization'], dataset_name,
                                                 f'{img_name}_{self.opt["name"]}.png')
                imwrite(metric_data['img'], save_img_path)

            if with_metrics:
                # calculate metrics
                for name, opt_ in self.opt['val']['metrics'].items():
                    self.metric_results[name] += calculate_metric(metric_data, opt_)
            if use_pbar:
                pbar.update(1)
                pbar.set_description(f'Test {img_name}')
        if use_pbar:
            pbar.close()

        if with_metrics:
            for metric in self.metric_results.keys():
                self.metric_results[metric] /= (idx + 1)
                # update the best metric result
                self._update_best_metric_result(dataset_name, metric, self.metric_results[metric], current_iter)

            self._log_validation_metric_values(current_iter, dataset_name, tb_logger)

    def _log_validation_metric_values(self, current_iter, dataset_name, tb_logger):
        log_str = f'Validation {dataset_name}\n'
        for metric, value in self.metric_results.items():
            log_str += f'\t # {metric}: {value:.4f}'
            if hasattr(self, 'best_metric_results'):
                log_str += (f'\tBest: {self.best_metric_results[dataset_name][metric]["val"]:.4f} @ '
                            f'{self.best_metric_results[dataset_name][metric]["iter"]} iter')
            log_str += '\n'

        logger = get_root_logger()
        logger.info(log_str)
        if tb_logger:
            for metric, value in self.metric_results.items():
                tb_logger.add_scalar(f'metrics/{dataset_name}/{metric}', value, current_iter)

    def get_current_visuals(self):
        out_dict = OrderedDict()
        out_dict['lq'] = self.lq.detach().cpu()
        out_dict['result'] = self.output.detach().cpu()
        if hasattr(self, 'gt'):
            out_dict['gt'] = self.gt.detach().cpu()
        return out_dict

    def save(self, epoch, current_iter):
        if hasattr(self, 'net_g_ema'):
            self.save_network([self.net_g, self.net_g_ema], 'net_g', current_iter, param_key=['params', 'params_ema'])
        else:
            self.save_network(self.net_g, 'net_g', current_iter)
        self.save_training_state(epoch, current_iter)
