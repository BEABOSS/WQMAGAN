import torch
from torch import nn as nn
from torch.nn import functional as F
from basicsr.utils.registry import ARCH_REGISTRY
from .arch_util import default_init_weights, make_layer, pixel_unshuffle

class ChannelAttention(nn.Module):
    """Channel attention used in RCAN.
    Args:
        num_feat (int): Channel number of intermediate features.
        squeeze_factor (int): Channel squeeze factor. Default: 16.
    """

    def __init__(self, num_feat, squeeze_factor=16):
        super(ChannelAttention, self).__init__()
        self.attention = nn.Sequential(
            nn.AdaptiveAvgPool2d(1),
            nn.Conv2d(num_feat, num_feat // squeeze_factor, 1, padding=0),
            nn.ReLU(inplace=True),
            nn.Conv2d(num_feat // squeeze_factor, num_feat, 1, padding=0),
            nn.Sigmoid())

    def forward(self, x):
        y = self.attention(x)
        return x * y


class CAB(nn.Module):

    def __init__(self, num_feat, compress_ratio=3, squeeze_factor=30):
        super(CAB, self).__init__()

        self.cab = nn.Sequential(
            nn.Conv2d(num_feat, num_feat // compress_ratio, 3, 1, 1),
            nn.GELU(),
            nn.Conv2d(num_feat // compress_ratio, num_feat, 3, 1, 1),
            ChannelAttention(num_feat, squeeze_factor)
            )

    def forward(self, x):
        return self.cab(x)
    
    
# ========== WSCP模块 ==========
from pytorch_wavelets import DWTForward, DWTInverse
class WSCP(nn.Module):
    def __init__(self, dim, wave='db3'):
        super(WSCP, self).__init__()

        self.dwt = DWTForward(J=1, mode='zero', wave=wave)
        self.idwt = DWTInverse(mode='zero', wave=wave)

        self.low_dila3 = nn.Sequential(
            nn.Conv2d(dim, dim, 3, 1, 3, dilation=3, groups=dim, bias=True),
            nn.GELU()
        )

        self.hi_fuse = nn.Sequential(
            nn.Conv2d(dim * 3, dim * 3, 3, 1, 1, groups=dim, bias=True),
            nn.GELU(),
            nn.Conv2d(dim * 3, dim * 3, 1, 1, 0, bias=True)
        )

    def forward(self, x):
        identity = x

        yl, yh = self.dwt(x)
        yh = yh[0]

        ylh = yh[:, :, 0]
        yhl = yh[:, :, 1]
        yhh = yh[:, :, 2]

        yl = self.low_dila3(yl)

        hi = torch.cat([ylh, yhl, yhh], dim=1)
        hi = self.hi_fuse(hi)

        B, C3, H, W = hi.shape
        C = C3 // 3

        yh = torch.stack([
            hi[:, 0:C],
            hi[:, C:2*C],
            hi[:, 2*C:3*C]
        ], dim=2)

        out = self.idwt((yl, [yh]))
        return out + identity

# ========== WQMA模块 ==========
class WQMA(nn.Module):
    """Multi-Dconv Head Transposed Attention"""
    def __init__(self, channels, num_heads):
        super(WQMA, self).__init__()
        self.num_heads = num_heads
        self.temperature = nn.Parameter(torch.ones(1, num_heads, 1, 1))

        self.qkv = nn.Conv2d(channels, channels * 2, kernel_size=1, bias=False)
        self.query = WSCP(channels)
        self.qkv_conv = nn.Conv2d(channels * 2, channels * 2, kernel_size=3, padding=1, groups=channels * 2, bias=False)
        self.project_out = nn.Conv2d(channels, channels, kernel_size=1, bias=False)

    def forward(self, x):
        b, c, h, w = x.shape
        k, v = self.qkv_conv(self.qkv(x)).chunk(2, dim=1)
        q = self.query(x)

        q = q.reshape(b, self.num_heads, -1, h * w)
        k = k.reshape(b, self.num_heads, -1, h * w)
        v = v.reshape(b, self.num_heads, -1, h * w)
        q, k = F.normalize(q, dim=-1), F.normalize(k, dim=-1)

        attn = torch.softmax(torch.matmul(q, k.transpose(-2, -1).contiguous()) * self.temperature, dim=-1)
        out = self.project_out(torch.matmul(attn, v).reshape(b, -1, h, w))
        return out


# ========== GDFN模块 ==========
class GDFN(nn.Module):
    """Gated-Dconv Feed-Forward Network"""
    def __init__(self, channels, expansion_factor):
        super(GDFN, self).__init__()
        hidden_channels = int(channels * expansion_factor)
        self.project_in = nn.Conv2d(channels, hidden_channels * 2, kernel_size=1, bias=False)
        self.conv = nn.Conv2d(hidden_channels * 2, hidden_channels * 2, kernel_size=3, padding=1,
                              groups=hidden_channels * 2, bias=False)
        self.project_out = nn.Conv2d(hidden_channels, channels, kernel_size=1, bias=False)

    def forward(self, x):
        x1, x2 = self.conv(self.project_in(x)).chunk(2, dim=1)
        x = self.project_out(F.gelu(x1) * x2)
        return x


# ========== TransformerBlock模块 ==========
class TransformerBlock(nn.Module):
    """Transformer Block with WQMA + CAB + GDFN"""

    def __init__(self, channels, num_heads, expansion_factor,
                 conv_scale=0.01, compress_ratio=3, squeeze_factor=30):
        super(TransformerBlock, self).__init__()
        
        self.norm1 = nn.LayerNorm(channels)
        self.attn = WQMA(channels, num_heads)

        self.conv_scale = conv_scale
        self.cab = CAB(
            num_feat=channels,
            compress_ratio=compress_ratio,
            squeeze_factor=squeeze_factor
        )

        self.norm2 = nn.LayerNorm(channels)
        self.ffn = GDFN(channels, expansion_factor)

    def forward(self, x):
        b, c, h, w = x.shape
        shortcut = x

        # ===== MSA =====
        attn_in = self.norm1(x.reshape(b, c, -1).transpose(-2, -1)).transpose(-2, -1)
        attn_in = attn_in.reshape(b, c, h, w)
        attn_out = self.attn(attn_in)

        # ===== CAB =====
        conv_out = self.cab(x)
        conv_out = conv_out * self.conv_scale

        # ===== Residual Fuse =====
        x = shortcut + attn_out + conv_out

        # ===== FFN =====
        ffn_in = self.norm2(x.reshape(b, c, -1).transpose(-2, -1)).transpose(-2, -1)
        ffn_in = ffn_in.reshape(b, c, h, w)
        x = x + self.ffn(ffn_in)

        return x


# ========== TransformerGroup模块 ==========
class TransformerGroup(nn.Module):
    """Group: 6 TransformerBlocks + 1 Conv + Residual Connection"""
    
    def __init__(self, channels, num_heads, expansion_factor, num_blocks=6,
                 conv_scale=0.01, compress_ratio=3, squeeze_factor=30):
        super(TransformerGroup, self).__init__()
        
        # 6个TransformerBlock
        self.blocks = nn.ModuleList([
            TransformerBlock(
                channels=channels,
                num_heads=num_heads,
                expansion_factor=expansion_factor,
                conv_scale=conv_scale,
                compress_ratio=compress_ratio,
                squeeze_factor=squeeze_factor
            ) for _ in range(num_blocks)
        ])
        
        # 组末尾的卷积层
        self.conv = nn.Conv2d(channels, channels, kernel_size=3, padding=1, bias=False)
        
    def forward(self, x):
        shortcut = x
        
        # 通过6个TransformerBlock
        for block in self.blocks:
            x = block(x)
        
        # 卷积层
        x = self.conv(x)
        
        # 残差连接
        x = x + shortcut
        
        return x


# ========== 主网络 ==========
# @ARCH_REGISTRY.register()
class TransformerNet(nn.Module):
    """
    完整网络架构:
    输入 -> 浅层特征提取 -> 6个TransformerGroup -> 重建模块 -> 输出
    """
    
    def __init__(self, 
                 in_channels=3,
                 out_channels=3,
                 channels=64,
                 num_heads=8,
                 expansion_factor=2.66,
                 num_groups=6,
                 num_blocks=6,
                 upscale=4,
                 conv_scale=0.01,
                 compress_ratio=3,
                 squeeze_factor=30):
        super(TransformerNet, self).__init__()
        
        # ===== 浅层特征提取 =====
        self.conv_first = nn.Conv2d(in_channels, channels, kernel_size=3, padding=1)
        
        # ===== 6个TransformerGroup =====
        self.groups = nn.ModuleList([
            TransformerGroup(
                channels=channels,
                num_heads=num_heads,
                expansion_factor=expansion_factor,
                num_blocks=num_blocks,
                conv_scale=conv_scale,
                compress_ratio=compress_ratio,
                squeeze_factor=squeeze_factor
            ) for _ in range(num_groups)
        ])
        
        # ===== 特征融合 =====
        self.conv_after_body = nn.Conv2d(channels, channels, kernel_size=3, padding=1)
        
        # ===== 重建模块 =====
        self.conv_before_upsample = nn.Sequential(
            nn.Conv2d(channels, channels, kernel_size=3, padding=1),
            nn.LeakyReLU(inplace=True)
        )
        
        # 上采样（固定4倍）
        self.upsample = self._make_upsample_layers(channels, upscale)
        
        # 最后的卷积
        self.conv_last = nn.Conv2d(channels, out_channels, kernel_size=3, padding=1)
        
        # 初始化权重（可选，PyTorch已有默认初始化）
        # self.apply(self._init_weights)
    
    def _make_upsample_layers(self, channels, upscale):
        """构建上采样层 - 固定4倍上采样"""
        # 4倍上采样 = 2次 2倍上采样
        layers = []
        for _ in range(2):
            layers.extend([
                nn.Conv2d(channels, channels * 4, kernel_size=3, padding=1),
                nn.PixelShuffle(2),
                nn.LeakyReLU(inplace=True)
            ])
        
        return nn.Sequential(*layers)
    
    def forward(self, x):
        # 浅层特征提取
        feat = self.conv_first(x)
        shallow_feat = feat
        
        # 通过6个TransformerGroup
        for group in self.groups:
            feat = group(feat)
        
        # 特征融合（全局残差连接）
        feat = self.conv_after_body(feat) + shallow_feat
        
        # 重建模块
        feat = self.conv_before_upsample(feat)
        feat = self.upsample(feat)
        out = self.conv_last(feat)
        
        return out