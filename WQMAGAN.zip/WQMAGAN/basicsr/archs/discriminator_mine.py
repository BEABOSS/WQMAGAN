import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.nn.utils import spectral_norm
from basicsr.utils.odconv import ODConv2d
from basicsr.utils.registry import ARCH_REGISTRY

class od_attention(nn.Module):
    def __init__(self, channels):
        super(od_attention, self).__init__()

        self.od_conv = ODConv2d(channels, channels, kernel_size=3, stride=1, padding=1)
        self.conv = nn.Conv2d(channels, channels, kernel_size=3, padding=1, bias=False)

    def forward(self, x):
        od_out = self.od_conv(x)
        out = self.conv(x)
        attention = F.gelu(od_out)
        return out*attention


@ARCH_REGISTRY.register(suffix='basicsr')# ===============================
#  U-Net Discriminator + od_attention
# ===============================
class UNetDiscriminatorOGA(nn.Module):
    """Defines a U-Net discriminator with spectral normalization (SN)
       (Modified: adds od_attention modules on skip connections)

    Args:
        num_in_ch (int): Number of input channels. Default: 3.
        num_feat (int): Number of base intermediate feature channels. Default: 64.
        skip_connection (bool): Whether to use skip connections between encoder/decoder. Default: True.
    """

    def __init__(self, num_in_ch, num_feat=64, skip_connection=True):
        super(UNetDiscriminatorOGA, self).__init__()
        self.skip_connection = skip_connection
        norm = spectral_norm

        # ---- Encoder ----
        self.conv0 = nn.Conv2d(num_in_ch, num_feat, kernel_size=3, stride=1, padding=1)
        self.conv1 = norm(nn.Conv2d(num_feat, num_feat * 2, 4, 2, 1, bias=False))
        self.conv2 = norm(nn.Conv2d(num_feat * 2, num_feat * 4, 4, 2, 1, bias=False))
        self.conv3 = norm(nn.Conv2d(num_feat * 4, num_feat * 8, 4, 2, 1, bias=False))

        # ---- Decoder ----
        self.conv4 = norm(nn.Conv2d(num_feat * 8, num_feat * 4, 3, 1, 1, bias=False))
        self.conv5 = norm(nn.Conv2d(num_feat * 4, num_feat * 2, 3, 1, 1, bias=False))
        self.conv6 = norm(nn.Conv2d(num_feat * 2, num_feat, 3, 1, 1, bias=False))

        # ---- Extra Conv Layers ----
        self.conv7 = norm(nn.Conv2d(num_feat, num_feat, 3, 1, 1, bias=False))
        self.conv8 = norm(nn.Conv2d(num_feat, num_feat, 3, 1, 1, bias=False))
        self.conv9 = nn.Conv2d(num_feat, 1, 3, 1, 1)

        # ---- od_attention modules (for skip connections) ----
        self.oga1 = od_attention(num_feat * 2)
        self.oga2 = od_attention(num_feat * 4)
        self.oga3 = od_attention(num_feat)

    def forward(self, x):
        # ---- Encoder path ----
        x0 = F.leaky_relu(self.conv0(x), 0.2, inplace=True)
        x1 = F.leaky_relu(self.conv1(x0), 0.2, inplace=True)
        x2 = F.leaky_relu(self.conv2(x1), 0.2, inplace=True)
        x3 = F.leaky_relu(self.conv3(x2), 0.2, inplace=True)

        # ---- Decoder path ----
        x3 = F.interpolate(x3, scale_factor=2, mode='bilinear', align_corners=False)
        x4 = F.leaky_relu(self.conv4(x3), 0.2, inplace=True)

        if self.skip_connection:
            x4 = x4 + self.oga2(x2)  # apply od_attention to skip feature

        x4 = F.interpolate(x4, scale_factor=2, mode='bilinear', align_corners=False)
        x5 = F.leaky_relu(self.conv5(x4), 0.2, inplace=True)

        if self.skip_connection:
            x5 = x5 + self.oga1(x1)

        x5 = F.interpolate(x5, scale_factor=2, mode='bilinear', align_corners=False)
        x6 = F.leaky_relu(self.conv6(x5), 0.2, inplace=True)

        if self.skip_connection:
            x6 = x6 + self.oga3(x0)

        # ---- Final Convolutions ----
        out = F.leaky_relu(self.conv7(x6), 0.2, inplace=True)
        out = F.leaky_relu(self.conv8(out), 0.2, inplace=True)
        out = self.conv9(out)

        return out