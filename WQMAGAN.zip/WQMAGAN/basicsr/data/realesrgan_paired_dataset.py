import os
import numpy as np
from torch.utils import data as data
from torchvision.transforms.functional import normalize

from basicsr.data.data_util import paired_paths_from_folder, paired_paths_from_lmdb
from basicsr.data.transforms import augment, paired_random_crop
from basicsr.utils import FileClient, imfrombytes, img2tensor
from basicsr.utils.registry import DATASET_REGISTRY


@DATASET_REGISTRY.register(suffix='basicsr')
class RealESRGAN4BandDataset(data.Dataset):
    """Paired 4-band remote sensing image dataset for image restoration.

    Read LQ (Low Quality, e.g. LR (Low Resolution), blurry, noisy, etc) and GT 4-band image pairs.
    Supports NIR-R-G-B or R-G-B-NIR band arrangements commonly used in remote sensing.

    There are three modes:

    1. **lmdb**: Use lmdb files. If opt['io_backend'] == lmdb.
    2. **meta_info_file**: Use meta information file to generate paths. \
        If opt['io_backend'] != lmdb and opt['meta_info_file'] is not None.
    3. **folder**: Scan folders to generate paths. The rest.

    Args:
        opt (dict): Config for train datasets. It contains the following keys:
        dataroot_gt (str): Data root path for gt.
        dataroot_lq (str): Data root path for lq.
        meta_info (str): Path for meta information file.
        io_backend (dict): IO backend type and other kwarg.
        filename_tmpl (str): Template for each filename. Note that the template excludes the file extension.
            Default: '{}'.
        gt_size (int): Cropped patched size for gt patches.
        use_hflip (bool): Use horizontal flips.
        use_rot (bool): Use rotation (use vertical flip and transposing h and w for implementation).
        scale (bool): Scale, which will be added automatically.
        phase (str): 'train' or 'val'.
        band_order (str): Band order arrangement. Options: 'NRGB', 'RGBN'. Default: 'NRGB'.
        normalize_per_band (bool): Whether to normalize each band separately. Default: True.
        clip_values (bool): Whether to clip values to [0, 1] range. Default: True.
    """

    def __init__(self, opt):
        super(RealESRGAN4BandDataset, self).__init__()
        self.opt = opt
        self.file_client = None
        self.io_backend_opt = opt['io_backend']

        # mean and std for normalizing the input images (4 channels)
        self.mean = opt['mean'] if 'mean' in opt else None
        self.std = opt['std'] if 'std' in opt else None

        # 4-band specific parameters
        self.band_order = opt.get('band_order', 'NRGB')  # NIR-R-G-B or R-G-B-NIR
        self.normalize_per_band = opt.get('normalize_per_band', True)
        self.clip_values = opt.get('clip_values', True)

        # Ensure mean and std are 4-dimensional if provided
        if self.mean is not None and len(self.mean) != 4:
            raise ValueError(f"Mean should have 4 values for 4-band images, got {len(self.mean)}")
        if self.std is not None and len(self.std) != 4:
            raise ValueError(f"Std should have 4 values for 4-band images, got {len(self.std)}")

        self.gt_folder, self.lq_folder = opt['dataroot_gt'], opt['dataroot_lq']
        self.filename_tmpl = opt['filename_tmpl'] if 'filename_tmpl' in opt else '{}'

        # file client (lmdb io backend)
        if self.io_backend_opt['type'] == 'lmdb':
            self.io_backend_opt['db_paths'] = [self.lq_folder, self.gt_folder]
            self.io_backend_opt['client_keys'] = ['lq', 'gt']
            self.paths = paired_paths_from_lmdb([self.lq_folder, self.gt_folder], ['lq', 'gt'])
        elif 'meta_info' in self.opt and self.opt['meta_info'] is not None:
            # disk backend with meta_info
            # Each line in the meta_info describes the relative path to an image
            with open(self.opt['meta_info']) as fin:
                paths = [line.strip() for line in fin]
            self.paths = []
            for path in paths:
                gt_path, lq_path = path.split(', ')
                gt_path = os.path.join(self.gt_folder, gt_path)
                lq_path = os.path.join(self.lq_folder, lq_path)
                self.paths.append(dict([('gt_path', gt_path), ('lq_path', lq_path)]))
        else:
            # disk backend
            # it will scan the whole folder to get meta info
            # it will be time-consuming for folders with too many files. It is recommended using an extra meta txt file
            self.paths = paired_paths_from_folder([self.lq_folder, self.gt_folder], ['lq', 'gt'], self.filename_tmpl)

    def _process_4band_image(self, img_bytes, client_key):
        """Process 4-band remote sensing image"""
        # Load image - assume it's already 4-band
        img = imfrombytes(img_bytes, float32=True)

        # Check if image has 4 channels
        if img.shape[2] != 4:
            raise ValueError(f"Expected 4-band image, got {img.shape[2]} bands")

        # Apply value clipping if enabled
        if self.clip_values:
            img = np.clip(img, 0.0, 1.0)

        # Handle different band orders if needed
        if self.band_order == 'RGBN':
            # Convert from R-G-B-NIR to N-R-G-B for consistency
            img = img[:, :, [3, 0, 1, 2]]  # NIR, R, G, B

        return img

    def _augment_4band(self, img_gt, img_lq, use_hflip, use_rot):
        """Augmentation function adapted for 4-band images"""
        # Use the existing augment function which should work with any number of channels
        return augment([img_gt, img_lq], use_hflip, use_rot)

    def _img2tensor_4band(self, imgs):
        """Convert 4-band images to tensors"""
        # Convert HWC to CHW and numpy to tensor, but don't do BGR2RGB conversion
        # since we're dealing with multispectral data
        tensors = []
        for img in imgs:
            # Ensure image is float32
            if img.dtype != np.float32:
                img = img.astype(np.float32)

            # Convert HWC to CHW
            img_tensor = img2tensor([img], bgr2rgb=False, float32=True)[0]
            tensors.append(img_tensor)

        return tensors

    def __getitem__(self, index):
        if self.file_client is None:
            self.file_client = FileClient(self.io_backend_opt.pop('type'), **self.io_backend_opt)

        scale = self.opt['scale']

        # Load gt and lq 4-band images. Dimension order: HWC; channel order: depends on band_order;
        # image range: [0, 1], float32.
        gt_path = self.paths[index]['gt_path']
        img_bytes = self.file_client.get(gt_path, 'gt')
        img_gt = self._process_4band_image(img_bytes, 'gt')

        lq_path = self.paths[index]['lq_path']
        img_bytes = self.file_client.get(lq_path, 'lq')
        img_lq = self._process_4band_image(img_bytes, 'lq')

        # augmentation for training
        if self.opt['phase'] == 'train':
            gt_size = self.opt['gt_size']
            # random crop
            img_gt, img_lq = paired_random_crop(img_gt, img_lq, gt_size, scale, gt_path)
            # flip, rotation - use custom 4-band augmentation
            img_gt, img_lq = self._augment_4band(img_gt, img_lq, self.opt['use_hflip'], self.opt['use_rot'])

        # HWC to CHW, numpy to tensor (no BGR2RGB conversion for multispectral)
        img_gt, img_lq = self._img2tensor_4band([img_gt, img_lq])

        # normalize - handle 4-band normalization
        if self.mean is not None or self.std is not None:
            if self.normalize_per_band:
                # Normalize each band separately
                normalize(img_lq, self.mean, self.std, inplace=True)
                normalize(img_gt, self.mean, self.std, inplace=True)
            else:
                # Use same normalization for all bands (using first 3 values if mean/std are 3D)
                mean_val = self.mean[:3] if self.mean is not None and len(self.mean) >= 3 else self.mean
                std_val = self.std[:3] if self.std is not None and len(self.std) >= 3 else self.std
                normalize(img_lq, mean_val, std_val, inplace=True)
                normalize(img_gt, mean_val, std_val, inplace=True)

        return {'lq': img_lq, 'gt': img_gt, 'lq_path': lq_path, 'gt_path': gt_path}

    def __len__(self):
        return len(self.paths)


# Alternative class name for backward compatibility
@DATASET_REGISTRY.register(suffix='basicsr')
class RealESRGANRemoteSensingDataset(RealESRGAN4BandDataset):
    """Alias for RealESRGAN4BandDataset for backward compatibility"""
    pass