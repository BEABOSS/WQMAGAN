import numpy as np
import torch
from torch.utils.data import Dataset
from osgeo import gdal
import os
from basicsr.data.transforms import augment, paired_random_crop
from basicsr.utils import FileClient, imfrombytes, img2tensor, scandir
from basicsr.utils.registry import DATASET_REGISTRY  # 确保导入注册表

@DATASET_REGISTRY.register()
class RemoteSensingDataset(Dataset):
    """
    用于多波段遥感图像超分辨率的数据集类
    使用GDAL读取支持各种遥感图像格式（包括GeoTIFF, IMG, HDF等）
    """
    def __init__(self, opt):
        super(RemoteSensingDataset, self).__init__()
        self.opt = opt
        
        # 文件路径设置
        self.gt_folder = opt['dataroot_gt']
        self.lq_folder = opt['dataroot_lq']
        
        # 支持的遥感图像格式
        self.supported_extensions = ['.tif', '.tiff', '.img', '.hdf', '.jp2', '.j2k']
        
        # 扫描所有图像文件
        self.gt_paths = self._scan_images(self.gt_folder)
        self.lq_paths = self._scan_images(self.lq_folder)
        
        assert len(self.gt_paths) == len(self.lq_paths), \
            f'GT和LQ图像数量不匹配: {len(self.gt_paths)} vs {len(self.lq_paths)}'
        
        # 参数设置
        self.scale = opt.get('scale', 4)
        self.gt_size = opt.get('gt_size', 128)
        self.use_hflip = opt.get('use_hflip', False)
        self.use_rot = opt.get('use_rot', False)
        self.target_bands = opt.get('target_bands', None)  # None表示使用所有波段
        self.normalize_method = opt.get('normalize_method', 'minmax')  # 'minmax', 'percentile', 'zscore'
        self.percentile_range = opt.get('percentile_range', [2, 98])  # 用于percentile归一化
        
        # 初始化GDAL
        gdal.UseExceptions()
        
        print(f"找到 {len(self.gt_paths)} 对训练图像")
        
        # 检查第一张图像的波段信息
        if len(self.gt_paths) > 0:
            self._check_image_info(self.gt_paths[0])
    
    def _scan_images(self, folder):
        """扫描指定文件夹中的遥感图像"""
        image_paths = []
        for ext in self.supported_extensions:
            pattern = f"*{ext}"
            paths = sorted(list(scandir(folder, suffix=ext, full_path=True)))
            image_paths.extend(paths)
        
        return sorted(image_paths)
    
    def _check_image_info(self, img_path):
        """检查并打印图像信息"""
        try:
            dataset = gdal.Open(img_path, gdal.GA_ReadOnly)
            if dataset is None:
                raise ValueError(f"无法打开图像: {img_path}")
            
            print(f"图像信息: {os.path.basename(img_path)}")
            print(f"  尺寸: {dataset.RasterXSize} x {dataset.RasterYSize}")
            print(f"  波段数: {dataset.RasterCount}")
            print(f"  数据类型: {gdal.GetDataTypeName(dataset.GetRasterBand(1).DataType)}")
            
            # 打印每个波段的统计信息
            for i in range(1, min(dataset.RasterCount + 1, 5)):  # 最多显示前4个波段
                band = dataset.GetRasterBand(i)
                stats = band.GetStatistics(True, True)
                print(f"  波段 {i}: Min={stats[0]:.2f}, Max={stats[1]:.2f}, Mean={stats[2]:.2f}, Std={stats[3]:.2f}")
            
            dataset = None  # 释放资源
            
        except Exception as e:
            print(f"检查图像信息时出错 {img_path}: {str(e)}")
    
    def __getitem__(self, index):
        # 获取文件路径
        gt_path = self.gt_paths[index]
        lq_path = self.lq_paths[index]
        
        try:
            # 读取GT图像
            img_gt = self._read_multiband_image(gt_path, is_gt=True)
            
            # 读取LQ图像  
            img_lq = self._read_multiband_image(lq_path, is_gt=False)
            
            # 确保GT和LQ有相同的波段数
            if img_gt.shape[2] != img_lq.shape[2]:
                raise ValueError(f"GT和LQ波段数不匹配: GT={img_gt.shape[2]}, LQ={img_lq.shape[2]}")
            
            # 数据增强和预处理
            img_gt, img_lq = self._preprocess(img_gt, img_lq)
            
            return {
                'lq': img_lq, 
                'gt': img_gt, 
                'lq_path': lq_path, 
                'gt_path': gt_path
            }
            
        except Exception as e:
            print(f"处理图像对失败 {gt_path}, {lq_path}: {str(e)}")
            # 返回下一个样本
            return self.__getitem__((index + 1) % len(self.gt_paths))
    
    def _read_multiband_image(self, img_path, is_gt=True):
        """使用GDAL读取多波段遥感图像"""
        try:
            # 打开图像
            dataset = gdal.Open(img_path, gdal.GA_ReadOnly)
            if dataset is None:
                raise ValueError(f"GDAL无法打开图像: {img_path}")
            
            # 获取图像基本信息
            width = dataset.RasterXSize
            height = dataset.RasterYSize
            band_count = dataset.RasterCount
            
            # 确定要读取的波段
            if self.target_bands is not None:
                bands_to_read = self.target_bands
                if max(bands_to_read) > band_count:
                    raise ValueError(f"目标波段 {max(bands_to_read)} 超出图像波段数 {band_count}")
            else:
                bands_to_read = list(range(1, band_count + 1))  # GDAL波段索引从1开始
            
            # 读取所有指定波段
            img_data = np.zeros((height, width, len(bands_to_read)), dtype=np.float32)
            
            for i, band_idx in enumerate(bands_to_read):
                band = dataset.GetRasterBand(band_idx)
                
                # 检查并处理NoData值
                nodata_value = band.GetNoDataValue()
                
                # 读取波段数据
                band_data = band.ReadAsArray().astype(np.float32)
                
                # 处理NoData值
                if nodata_value is not None:
                    band_data[band_data == nodata_value] = 0.0
                
                # 处理异常值
                band_data = np.clip(band_data, 
                                  np.percentile(band_data, 0.1), 
                                  np.percentile(band_data, 99.9))
                
                img_data[:, :, i] = band_data
            
            # 释放GDAL数据集
            dataset = None
            
            # 数据归一化
            img_data = self._normalize_image(img_data, img_path)
            
            return img_data
            
        except Exception as e:
            print(f"读取图像失败 {img_path}: {str(e)}")
            raise e
    
    def _normalize_image(self, img, img_path):
        """归一化图像数据"""
        try:
            if self.normalize_method == 'minmax':
                # 按波段分别进行最小-最大归一化
                normalized_img = np.zeros_like(img)
                for i in range(img.shape[2]):
                    band = img[:, :, i]
                    band_min, band_max = band.min(), band.max()
                    if band_max > band_min:
                        normalized_img[:, :, i] = (band - band_min) / (band_max - band_min)
                    else:
                        normalized_img[:, :, i] = band
                        
            elif self.normalize_method == 'percentile':
                # 使用百分位数归一化，更robust
                normalized_img = np.zeros_like(img)
                for i in range(img.shape[2]):
                    band = img[:, :, i]
                    p_low = np.percentile(band, self.percentile_range[0])
                    p_high = np.percentile(band, self.percentile_range[1])
                    if p_high > p_low:
                        normalized_img[:, :, i] = np.clip((band - p_low) / (p_high - p_low), 0, 1)
                    else:
                        normalized_img[:, :, i] = band
                        
            elif self.normalize_method == 'zscore':
                # Z-score标准化
                normalized_img = np.zeros_like(img)
                for i in range(img.shape[2]):
                    band = img[:, :, i]
                    mean, std = band.mean(), band.std()
                    if std > 0:
                        normalized_img[:, :, i] = (band - mean) / std
                        # 将z-score结果映射到[0,1]
                        band_norm = normalized_img[:, :, i]
                        band_min, band_max = band_norm.min(), band_norm.max()
                        if band_max > band_min:
                            normalized_img[:, :, i] = (band_norm - band_min) / (band_max - band_min)
                    else:
                        normalized_img[:, :, i] = band
            else:
                # 默认简单归一化
                normalized_img = img / (img.max() + 1e-8)
            
            return normalized_img
            
        except Exception as e:
            print(f"归一化图像失败 {img_path}: {str(e)}")
            # 返回简单归一化结果
            return img / (img.max() + 1e-8)
    
    def _preprocess(self, img_gt, img_lq):
        """数据预处理和增强"""
        # 随机裁剪到指定大小
        gt_size = self.gt_size
        lq_size = gt_size // self.scale
        
        # 确保图像尺寸足够大
        if img_gt.shape[0] < gt_size or img_gt.shape[1] < gt_size:
            # 如果图像太小，进行填充
            pad_h = max(0, gt_size - img_gt.shape[0])
            pad_w = max(0, gt_size - img_gt.shape[1])
            img_gt = np.pad(img_gt, ((0, pad_h), (0, pad_w), (0, 0)), mode='reflect')
            
        if img_lq.shape[0] < lq_size or img_lq.shape[1] < lq_size:
            pad_h = max(0, lq_size - img_lq.shape[0])
            pad_w = max(0, lq_size - img_lq.shape[1])
            img_lq = np.pad(img_lq, ((0, pad_h), (0, pad_w), (0, 0)), mode='reflect')
        
        # 配对随机裁剪
        img_gt, img_lq = paired_random_crop(img_gt, img_lq, gt_size, self.scale)
        
        # 数据增强
        if self.use_hflip or self.use_rot:
            img_gt, img_lq = augment([img_gt, img_lq], self.use_hflip, self.use_rot)
        
        # 转换为tensor格式 (C, H, W)
        img_gt = img2tensor(img_gt, bgr2rgb=False, float32=True)
        img_lq = img2tensor(img_lq, bgr2rgb=False, float32=True)
        
        return img_gt, img_lq
    
    def __len__(self):
        return len(self.gt_paths)


# 测试代码分离到独立模块，避免影响主模块
if __name__ == '__main__':
    def test_dataset():
        """测试数据集是否正常工作"""
        # 测试配置
        opt = {
            'dataroot_gt': 'datasets/train/HR',  # 替换为你的HR图像路径
            'dataroot_lq': 'datasets/train/LRx4',
            'scale': 4,
            'gt_size': 128,
            'use_hflip': True,
            'use_rot': True,
            'target_bands': None,  # 使用所有波段，或指定如 [1, 2, 3, 4]
            'normalize_method': 'percentile',  # 'minmax', 'percentile', 'zscore'
            'percentile_range': [2, 98]
        }
        
        print("开始测试RemoteSensingDataset...")
        
        try:
            dataset = RemoteSensingDataset(opt)
            print(f"数据集大小: {len(dataset)}")
            
            if len(dataset) == 0:
                print("警告: 数据集为空，请检查数据路径和文件格式")
                return
            
            # 测试读取前几个样本
            for i in range(min(3, len(dataset))):
                print(f"\n测试样本 {i}:")
                sample = dataset[i]
                print(f"  GT shape: {sample['gt'].shape}")  # 应该是 [C, H, W]
                print(f"  LQ shape: {sample['lq'].shape}")  # 应该是 [C, H, W]
                print(f"  GT数据范围: [{sample['gt'].min():.4f}, {sample['gt'].max():.4f}]")
                print(f"  LQ数据范围: [{sample['lq'].min():.4f}, {sample['lq'].max():.4f}]")
                print(f"  GT路径: {sample['gt_path']}")
                print(f"  LQ路径: {sample['lq_path']}")
            
            print("\n数据集测试成功！")
            
        except Exception as e:
            print(f"数据集测试失败: {str(e)}")
            import traceback
            traceback.print_exc()

    def check_gdal_installation():
        """检查GDAL是否正确安装"""
        try:
            from osgeo import gdal
            print(f"GDAL版本: {gdal.VersionInfo()}")
            
            # 检查支持的驱动
            driver_count = gdal.GetDriverCount()
            print(f"支持的GDAL驱动数量: {driver_count}")
            
            # 列出一些常用的遥感图像驱动
            common_drivers = ['GTiff', 'HDF4', 'HDF5', 'JPEG2000', 'JP2ECW']
            print("常用遥感格式支持情况:")
            for driver_name in common_drivers:
                driver = gdal.GetDriverByName(driver_name)
                if driver:
                    print(f"  ✓ {driver_name}")
                else:
                    print(f"  ✗ {driver_name}")
                    
            return True
            
        except ImportError:
            print("错误: GDAL未安装")
            print("请安装GDAL: conda install -c conda-forge gdal")
            return False

    # 首先检查GDAL安装
    if check_gdal_installation():
        print("\n" + "="*50)
        test_dataset()