# import os
# import os.path as osp
# import torch
# from torch import nn
# from torch.nn import functional as F
# import torch.nn.init as init
# import numpy as np
# import glob

# from osgeo import gdal, osr
# from basicsr.utils.registry import ARCH_REGISTRY
# from basicsr.archs.arch_util import default_init_weights, make_layer, pixel_unshuffle



# class ResidualDenseBlock(nn.Module):
#     """Residual Dense Block.

#     Used in RRDB block in ESRGAN.

#     Args:
#         num_feat (int): Channel number of intermediate features.
#         num_grow_ch (int): Channels for each growth.
#     """

#     def __init__(self, num_feat=64, num_grow_ch=32):
#         super(ResidualDenseBlock, self).__init__()
#         self.conv1 = nn.Conv2d(num_feat, num_grow_ch, 3, 1, 1)
#         self.conv2 = nn.Conv2d(num_feat + num_grow_ch, num_grow_ch, 3, 1, 1)
#         self.conv3 = nn.Conv2d(num_feat + 2 * num_grow_ch, num_grow_ch, 3, 1, 1)
#         self.conv4 = nn.Conv2d(num_feat + 3 * num_grow_ch, num_grow_ch, 3, 1, 1)
#         self.conv5 = nn.Conv2d(num_feat + 4 * num_grow_ch, num_feat, 3, 1, 1)

#         self.lrelu = nn.LeakyReLU(negative_slope=0.2, inplace=True)

#         # initialization
#         default_init_weights([self.conv1, self.conv2, self.conv3, self.conv4, self.conv5], 0.1)

#     def forward(self, x):
#         x1 = self.lrelu(self.conv1(x))
#         x2 = self.lrelu(self.conv2(torch.cat((x, x1), 1)))
#         x3 = self.lrelu(self.conv3(torch.cat((x, x1, x2), 1)))
#         x4 = self.lrelu(self.conv4(torch.cat((x, x1, x2, x3), 1)))
#         x5 = self.conv5(torch.cat((x, x1, x2, x3, x4), 1))
#         # Empirically, we use 0.2 to scale the residual for better performance
#         return x5 * 0.2 + x


# class RRDB(nn.Module):
#     """Residual in Residual Dense Block.

#     Used in RRDB-Net in ESRGAN.

#     Args:
#         num_feat (int): Channel number of intermediate features.
#         num_grow_ch (int): Channels for each growth.
#     """

#     def __init__(self, num_feat, num_grow_ch=32):
#         super(RRDB, self).__init__()
#         self.rdb1 = ResidualDenseBlock(num_feat, num_grow_ch)
#         self.rdb2 = ResidualDenseBlock(num_feat, num_grow_ch)
#         self.rdb3 = ResidualDenseBlock(num_feat, num_grow_ch)

#     def forward(self, x):
#         out = self.rdb1(x)
#         out = self.rdb2(out)
#         out = self.rdb3(out)
#         # Empirically, we use 0.2 to scale the residual for better performance
#         return out * 0.2 + x



# class RRDBNet(nn.Module):
#     """Networks consisting of Residual in Residual Dense Block, which is used
#     in ESRGAN.

#     ESRGAN: Enhanced Super-Resolution Generative Adversarial Networks.

#     We extend ESRGAN for scale x2 and scale x1.
#     Note: This is one option for scale 1, scale 2 in RRDBNet.
#     We first employ the pixel-unshuffle (an inverse operation of pixelshuffle to reduce the spatial size
#     and enlarge the channel size before feeding inputs into the main ESRGAN architecture.

#     Args:
#         num_in_ch (int): Channel number of inputs.
#         num_out_ch (int): Channel number of outputs.
#         num_feat (int): Channel number of intermediate features.
#             Default: 64
#         num_block (int): Block number in the trunk network. Defaults: 23
#         num_grow_ch (int): Channels for each growth. Default: 32.
#     """

#     def __init__(self, num_in_ch, num_out_ch, scale=4, num_feat=64, num_block=23, num_grow_ch=32):
#         super(RRDBNet, self).__init__()
#         self.scale = scale
#         if scale == 2:
#             num_in_ch = num_in_ch * 4
#         elif scale == 1:
#             num_in_ch = num_in_ch * 16
#         self.conv_first = nn.Conv2d(num_in_ch, num_feat, 3, 1, 1)
#         self.body = make_layer(RRDB, num_block, num_feat=num_feat, num_grow_ch=num_grow_ch)
#         self.conv_body = nn.Conv2d(num_feat, num_feat, 3, 1, 1)
#         # upsample
#         self.conv_up1 = nn.Conv2d(num_feat, num_feat, 3, 1, 1)
#         self.conv_up2 = nn.Conv2d(num_feat, num_feat, 3, 1, 1)
#         self.conv_hr = nn.Conv2d(num_feat, num_feat, 3, 1, 1)
#         self.conv_last = nn.Conv2d(num_feat, num_out_ch, 3, 1, 1)

#         self.lrelu = nn.LeakyReLU(negative_slope=0.2, inplace=True)

#     def forward(self, x):
#         if self.scale == 2:
#             feat = pixel_unshuffle(x, scale=2)
#         elif self.scale == 1:
#             feat = pixel_unshuffle(x, scale=4)
#         else:
#             feat = x
#         feat = self.conv_first(feat)
#         body_feat = self.conv_body(self.body(feat))
#         feat = feat + body_feat
#         # upsample
#         feat = self.lrelu(self.conv_up1(F.interpolate(feat, scale_factor=2, mode='nearest')))
#         feat = self.lrelu(self.conv_up2(F.interpolate(feat, scale_factor=2, mode='nearest')))
#         out = self.conv_last(self.lrelu(self.conv_hr(feat)))
#         return out




# def analyze_model_weights(state_dict):
#     """分析权重文件并推断模型参数"""
#     print("分析权重文件结构...")
    
#     # 打印所有键名以便调试
#     all_keys = list(state_dict.keys())
#     print(f"权重文件包含 {len(all_keys)} 个参数")
#     print("前10个键名:")
#     for i, key in enumerate(all_keys[:10]):
#         print(f"  {i+1}: {key}")
    
#     # 查找关键层的权重
#     conv_first_key = None
#     conv_last_key = None
#     conv_body_key = None
    
#     for key in all_keys:
#         if 'conv_first.weight' in key:
#             conv_first_key = key
#         elif 'conv_last.weight' in key:
#             conv_last_key = key
#         elif 'conv_body.weight' in key:
#             conv_body_key = key
    
#     print(f"\n找到的关键层:")
#     print(f"  conv_first: {conv_first_key}")
#     print(f"  conv_last: {conv_last_key}")
#     print(f"  conv_body: {conv_body_key}")
    
#     if not conv_first_key or not conv_last_key:
#         raise ValueError("无法找到conv_first或conv_last层的权重")
    
#     # 从权重形状推断参数
#     conv_first_weight = state_dict[conv_first_key]
#     conv_last_weight = state_dict[conv_last_key]
    
#     num_in_ch = conv_first_weight.shape[1]  # 输入通道
#     num_out_ch = conv_last_weight.shape[0]  # 输出通道
#     num_feat = conv_first_weight.shape[0]   # 特征通道数
    
#     # 计算RRDB块数量
#     num_blocks = len([k for k in all_keys if k.startswith('body.') and 'rdb1.conv1.weight' in k])
    
#     # 改进的缩放因子推断逻辑
#     up_block_keys = [k for k in all_keys if 'up_blocks.' in k or 'upconv' in k or 'upsample' in k]
#     # 检查是否有conv_up1和conv_up2层，这是4倍超分辨率模型的特征
#     has_conv_up1 = any('conv_up1' in k for k in all_keys)
#     has_conv_up2 = any('conv_up2' in k for k in all_keys)
    
#     if up_block_keys:
#         # 方法1: 通过up_blocks数量推断
#         unique_up_blocks = set()
#         for key in up_block_keys:
#             if 'up_blocks.' in key:
#                 block_idx = key.split('.')[1]
#                 unique_up_blocks.add(block_idx)
#         num_upsamples = len(unique_up_blocks)
#     elif has_conv_up1 and has_conv_up2:
#         # 如果同时有conv_up1和conv_up2，这很可能是4倍超分辨率模型
#         print("检测到conv_up1和conv_up2层,假设为4倍超分辨率")
#         num_upsamples = 2  # 4倍超分辨率需要2次上采样
#     else:
#         # 方法2: 如果没有找到up_blocks，尝试其他方法
#         # 检查是否有HRConv或其他上采样相关的层
#         hr_keys = [k for k in all_keys if 'hr' in k.lower() or 'upsample' in k.lower()]
#         if hr_keys:
#             print("检测到HR相关层,默认使用2倍超分辨率")
#             num_upsamples = 1
#         else:
#             print("无法确定上采样层,默认使用2倍超分辨率")
#             num_upsamples = 1
    
#     scale = 2 ** num_upsamples
    
#     return {
#         'num_in_ch': num_in_ch,
#         'num_out_ch': num_out_ch,
#         'num_feat': num_feat,
#         'num_block': num_blocks,
#         'scale': scale,
#         'conv_first_key': conv_first_key,
#         'conv_last_key': conv_last_key,
#         'conv_body_key': conv_body_key
#     }

# def create_model_from_weights(state_dict):
#     """根据权重文件创建匹配的模型"""
#     try:
#         params = analyze_model_weights(state_dict)
        
#         print(f"\n推断的模型参数:")
#         print(f"  num_in_ch: {params['num_in_ch']}")
#         print(f"  num_out_ch: {params['num_out_ch']}")
#         print(f"  num_feat: {params['num_feat']}")
#         print(f"  num_block: {params['num_block']}")
#         print(f"  scale: {params['scale']}")
        
#         # 计算实际的输入通道数，需要考虑scale对num_in_ch的影响
#         original_num_in_ch = params['num_in_ch']
#         adjusted_num_in_ch = original_num_in_ch
        
#         # 如果scale=2，num_in_ch会被乘以4；如果scale=1，num_in_ch会被乘以16
#         # 因此我们需要反向计算，以确保模型使用正确的输入通道数
#         if params['scale'] == 2:
#             adjusted_num_in_ch = original_num_in_ch // 4
#         elif params['scale'] == 1:
#             adjusted_num_in_ch = original_num_in_ch // 16
        
#         print(f"  调整后的num_in_ch: {adjusted_num_in_ch}")
        
#         # 创建模型时使用调整后的num_in_ch
#         model = RRDBNet(
#             num_in_ch=adjusted_num_in_ch,
#             num_out_ch=params['num_out_ch'],
#             num_feat=params['num_feat'],
#             num_block=params['num_block'],
#             num_grow_ch=32,
#             scale=params['scale']
#         )
        
#         return model, params
        
#     except Exception as e:
#         print(f"自动推断失败: {e}")
#         print("使用默认参数创建模型...")
        
#         # 使用默认参数
#         default_params = {
#             'num_in_ch': 4,
#             'num_out_ch': 4,
#             'num_feat': 64,
#             'num_block': 23,
#             'scale': 4  # 这里也可以根据您的需求修改为默认4倍
#         }
        
#         model = RRDBNet(**default_params)
#         return model, default_params

# # 模型路径
# model_path = r"D:\net_g_latest.pth"
# # 如果模型路径不存在，抛出错误
# assert osp.exists(model_path), "Model path does not exist!"

# # 设备设置
# device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
# print(f"使用设备: {device}")

# # 测试图像文件夹或单个文件路径
# test_img_folder = r"C:\Users\22174\Desktop\test\shandong_uint8_1_10.tif"


# # 创建结果目录
# results_dir = 'results'
# os.makedirs(results_dir, exist_ok=True)

# # 加载权重文件
# print("加载权重文件...")
# checkpoint = torch.load(model_path, map_location='cpu')

# # 检查权重文件结构并选择正确的权重
# if 'params_ema' in checkpoint:
#     state_dict = checkpoint['params_ema']
#     print("找到 EMA 权重")
# elif 'params' in checkpoint:
#     state_dict = checkpoint['params']
#     print("找到普通权重")
# else:
#     state_dict = checkpoint
#     print("使用根级权重")

# # 创建模型
# model, model_params = create_model_from_weights(state_dict)

# # 加载权重
# print(f'Loading model from {model_path}')
# try:
#     model.load_state_dict(state_dict, strict=True)
#     print("模型权重加载成功!")
# except Exception as e:
#     print(f"严格加载失败: {e}")
#     print("尝试非严格加载...")
#     model.load_state_dict(state_dict, strict=False)
#     print("非严格加载完成!")

# model.eval()
# model = model.to(device)

# print('Model path {:s}. \nTesting...'.format(model_path))

# def read_tif_with_gdal(file_path):
#     """
#     使用GDAL读取TIF文件
#     返回：图像数据(numpy数组), 地理变换参数, 投影信息
#     """
#     try:
#         dataset = gdal.Open(file_path)
#         if dataset is None:
#             print(f"Error: Cannot open {file_path}")
#             return None, None, None

#         # 获取图像信息
#         width = dataset.RasterXSize
#         height = dataset.RasterYSize
#         bands = dataset.RasterCount

#         print(f"Image info: {width}x{height}, {bands} bands")

#         # 读取所有波段数据
#         img_data = []
#         for i in range(1, bands + 1):
#             band = dataset.GetRasterBand(i)
#             band_data = band.ReadAsArray()
#             img_data.append(band_data)

#         img_data = np.stack(img_data, axis=0)  # Shape: (bands, height, width)

#         # 获取地理信息
#         geotransform = dataset.GetGeoTransform()
#         projection = dataset.GetProjection()

#         dataset = None  # 关闭数据集

#         return img_data, geotransform, projection

#     except Exception as e:
#         print(f"Error reading {file_path}: {str(e)}")
#         return None, None, None

# def save_tif_with_gdal(output_data, save_path, geotransform, projection, scale_factor=2):
#     """
#     使用GDAL保存TIF文件，保留地理信息
#     """
#     try:
#         # 获取输出数据的形状
#         bands, height, width = output_data.shape

#         # 调整地理变换参数以适应超分辨率
#         new_geotransform = list(geotransform)
#         new_geotransform[1] = geotransform[1] / scale_factor  # 像素大小X方向
#         new_geotransform[5] = geotransform[5] / scale_factor  # 像素大小Y方向

#         # 创建输出数据集
#         driver = gdal.GetDriverByName('GTiff')
#         out_dataset = driver.Create(save_path, width, height, bands, gdal.GDT_Float32)

#         # 设置地理变换和投影
#         out_dataset.SetGeoTransform(new_geotransform)
#         out_dataset.SetProjection(projection)

#         # 写入每个波段
#         for i in range(bands):
#             out_band = out_dataset.GetRasterBand(i + 1)
#             out_band.WriteArray(output_data[i])
#             out_band.FlushCache()

#         out_dataset = None  # 关闭数据集
#         print(f"Successfully saved: {save_path}")

#     except Exception as e:
#         print(f"Error saving {save_path}: {str(e)}")

# def normalize_image(img_data):
#     """
#     归一化图像数据到[0,1]范围
#     """
#     # 检查数据类型和范围
#     print(f"Original data range: min={np.min(img_data):.4f}, max={np.max(img_data):.4f}")
#     print(f"Original data type: {img_data.dtype}")

#     # 逐波段归一化
#     img_normalized = np.zeros_like(img_data, dtype=np.float32)
#     for i in range(img_data.shape[0]):
#         band_min = np.min(img_data[i])
#         band_max = np.max(img_data[i])
#         if band_max > band_min:
#             img_normalized[i] = (img_data[i] - band_min) / (band_max - band_min)
#         else:
#             img_normalized[i] = np.zeros_like(img_data[i])
#         print(f"  Band {i+1}: [{band_min:.4f}, {band_max:.4f}] -> [0, 1]")

#     print(f"Normalized data range: min={np.min(img_normalized):.4f}, max={np.max(img_normalized):.4f}")
#     return img_normalized

# def denormalize_image(img_normalized, original_data):
#     """
#     将归一化后的图像恢复到原始数据范围
#     """
#     img_denormalized = np.zeros_like(img_normalized, dtype=original_data.dtype)
#     for i in range(img_normalized.shape[0]):
#         band_min = np.min(original_data[i])
#         band_max = np.max(original_data[i])
#         if band_max > band_min:
#             img_denormalized[i] = img_normalized[i] * (band_max - band_min) + band_min
#         else:
#             img_denormalized[i] = np.full_like(img_normalized[i], band_min)

#     return img_denormalized

# def tile_process(img_data, model, device, tile_size=512, overlap=32):
#     """
#     分块处理大图像
#     """
#     print(f"使用分块处理，tile_size={tile_size}, overlap={overlap}")
    
#     bands, height, width = img_data.shape
#     scale = model.scale
    
#     # 输出图像尺寸
#     output_h = height * scale
#     output_w = width * scale
#     output_img = np.zeros((bands, output_h, output_w), dtype=np.float32)
    
#     # 计算分块数量
#     stride = tile_size - overlap
#     h_tiles = (height - overlap + stride - 1) // stride
#     w_tiles = (width - overlap + stride - 1) // stride
    
#     print(f"图像尺寸: {height}x{width}, 分块数量: {h_tiles}x{w_tiles}")
    
#     for i in range(h_tiles):
#         for j in range(w_tiles):
#             # 计算当前块的位置
#             start_h = i * stride
#             start_w = j * stride
#             end_h = min(start_h + tile_size, height)
#             end_w = min(start_w + tile_size, width)
            
#             # 提取当前块
#             tile = img_data[:, start_h:end_h, start_w:end_w]
            
#             # 转换为tensor并推理
#             tile_tensor = torch.from_numpy(tile).float().unsqueeze(0).to(device)
            
#             with torch.no_grad():
#                 output_tile_tensor = model(tile_tensor)
#                 output_tile = output_tile_tensor.squeeze(0).cpu().numpy()
            
#             # 计算输出位置
#             out_start_h = start_h * scale
#             out_start_w = start_w * scale
#             out_end_h = out_start_h + output_tile.shape[1]
#             out_end_w = out_start_w + output_tile.shape[2]
            
#             # 处理边界重叠
#             if i > 0:  # 不是第一行
#                 overlap_h = overlap * scale
#                 output_tile = output_tile[:, overlap_h//2:, :]
#                 out_start_h += overlap_h//2
                
#             if j > 0:  # 不是第一列
#                 overlap_w = overlap * scale
#                 output_tile = output_tile[:, :, overlap_w//2:]
#                 out_start_w += overlap_w//2
            
#             # 放置到输出图像中
#             out_end_h = min(out_start_h + output_tile.shape[1], output_h)
#             out_end_w = min(out_start_w + output_tile.shape[2], output_w)
            
#             output_img[:, out_start_h:out_end_h, out_start_w:out_end_w] = \
#                 output_tile[:, :out_end_h-out_start_h, :out_end_w-out_start_w]
            
#             print(f"完成分块 {i+1}/{h_tiles}, {j+1}/{w_tiles}")
    
#     return output_img

# # 检查是否可以找到测试文件
# if not glob.glob(test_img_folder):
#     print(f"Warning: No files found at {test_img_folder}")
#     print("Please check the file path.")
#     exit()

# idx = 0
# # 遍历测试图像
# for path in glob.glob(test_img_folder):
#     idx += 1
#     base = osp.splitext(osp.basename(path))[0]
#     print(f"\n{'='*60}")
#     print(f"{idx}: Processing {base}")
#     print(f"{'='*60}")

#     # 使用GDAL读取TIF文件
#     img_data, geotransform, projection = read_tif_with_gdal(path)

#     if img_data is None:
#         print(f"Warning: Image {path} could not be read, skipping...")
#         continue

#     # 检查波段数是否匹配
#     expected_channels = model_params['num_in_ch']
#     if img_data.shape[0] != expected_channels:
#         print(f"Warning: Image {path} has {img_data.shape[0]} bands, but model expects {expected_channels} bands")
        
#         # 尝试调整通道数
#         if img_data.shape[0] == 1 and expected_channels == 3:
#             # 灰度图转RGB
#             img_data = np.repeat(img_data, 3, axis=0)
#             print(f"转换为3通道图像")
#         elif img_data.shape[0] == 3 and expected_channels == 1:
#             # RGB转灰度
#             img_data = np.mean(img_data, axis=0, keepdims=True)
#             print(f"转换为单通道图像")
#         elif img_data.shape[0] == 3 and expected_channels == 4:
#             # 为3波段图像添加空波段以适配4波段模型
#             # 创建一个与原图像形状相同的零数组，但增加一个波段
#             empty_band = np.zeros((1, img_data.shape[1], img_data.shape[2]), dtype=img_data.dtype)
#             # 将原图像和空波段连接
#             img_data = np.concatenate([img_data, empty_band], axis=0)
#             print(f"为3波段图像添加空波段，转换为4通道图像")
#         elif img_data.shape[0] > expected_channels:
#             # 裁剪多余通道
#             img_data = img_data[:expected_channels]
#             print(f"裁剪到{expected_channels}通道")
#         else:
#             print(f"无法处理通道数不匹配，跳过...")
#             continue

#     print(f"Original image shape: {img_data.shape}")

#     # 保存原始数据用于反归一化
#     original_img_data = img_data.copy()

#     # 图像预处理 - 归一化到[0,1]
#     img_normalized = normalize_image(img_data.astype(np.float32))

#     # 判断是否需要分块处理
#     _, height, width = img_normalized.shape
#     tile_size = 512  # 可根据显存大小调整
    
#     try:
#         if height > tile_size or width > tile_size:
#             print("图像较大，使用分块处理...")
#             output = tile_process(img_normalized, model, device, tile_size)
#         else:
#             print("图像较小，使用整图处理...")
#             # 转换为PyTorch张量
#             img_tensor = torch.from_numpy(img_normalized).float().unsqueeze(0)
#             img_tensor = img_tensor.to(device)

#             print(f"Input tensor shape: {img_tensor.shape}")
#             print(f"Input tensor device: {img_tensor.device}")

#             with torch.no_grad():
#                 # 模型推理
#                 print("Running inference...")
#                 output = model(img_tensor).data.squeeze().float().cpu().numpy()
#                 print(f"Output tensor shape: {output.shape}")
#                 print("Inference completed successfully!")

#         # 确保输出在[0,1]范围内
#         output = np.clip(output, 0, 1)
#         print(f"Output data range after clipping: min={np.min(output):.4f}, max={np.max(output):.4f}")

#         # 反归一化到原始数据范围
#         output_denormalized = denormalize_image(output, original_img_data)
#         print(f"Denormalized output range: min={np.min(output_denormalized):.4f}, max={np.max(output_denormalized):.4f}")
#         print(f"Denormalized output type: {output_denormalized.dtype}")

#         # 保存结果
#         save_path = osp.join(results_dir, f'{base}_sr.tif')
#         save_tif_with_gdal(output_denormalized, save_path, geotransform, projection, scale_factor=model_params['scale'])

#         print(f"Processing completed for {base}")
        
#     except Exception as e:
#         print(f"Error during processing: {e}")
#         import traceback
#         traceback.print_exc()
#         continue

# print(f"\n{'='*60}")
# print("All processing completed!")
# print(f"Results saved in: {osp.abspath(results_dir)}")
# print(f"{'='*60}")

import os
import os.path as osp
import torch
from torch import nn
from torch.nn import functional as F
import torch.nn.init as init
import numpy as np
import glob

from osgeo import gdal, osr
from basicsr.utils.registry import ARCH_REGISTRY
from basicsr.archs.arch_util import default_init_weights, make_layer, pixel_unshuffle


# ----------------- 原有模型定义（保持不变） -----------------
class ResidualDenseBlock(nn.Module):
    """Residual Dense Block.
    Used in RRDB block in ESRGAN.
    """
    def __init__(self, num_feat=64, num_grow_ch=32):
        super(ResidualDenseBlock, self).__init__()
        self.conv1 = nn.Conv2d(num_feat, num_grow_ch, 3, 1, 1)
        self.conv2 = nn.Conv2d(num_feat + num_grow_ch, num_grow_ch, 3, 1, 1)
        self.conv3 = nn.Conv2d(num_feat + 2 * num_grow_ch, num_grow_ch, 3, 1, 1)
        self.conv4 = nn.Conv2d(num_feat + 3 * num_grow_ch, num_grow_ch, 3, 1, 1)
        self.conv5 = nn.Conv2d(num_feat + 4 * num_grow_ch, num_feat, 3, 1, 1)

        self.lrelu = nn.LeakyReLU(negative_slope=0.2, inplace=True)
        default_init_weights([self.conv1, self.conv2, self.conv3, self.conv4, self.conv5], 0.1)

    def forward(self, x):
        x1 = self.lrelu(self.conv1(x))
        x2 = self.lrelu(self.conv2(torch.cat((x, x1), 1)))
        x3 = self.lrelu(self.conv3(torch.cat((x, x1, x2), 1)))
        x4 = self.lrelu(self.conv4(torch.cat((x, x1, x2, x3), 1)))
        x5 = self.conv5(torch.cat((x, x1, x2, x3, x4), 1))
        return x5 * 0.2 + x


class RRDB(nn.Module):
    def __init__(self, num_feat, num_grow_ch=32):
        super(RRDB, self).__init__()
        self.rdb1 = ResidualDenseBlock(num_feat, num_grow_ch)
        self.rdb2 = ResidualDenseBlock(num_feat, num_grow_ch)
        self.rdb3 = ResidualDenseBlock(num_feat, num_grow_ch)

    def forward(self, x):
        out = self.rdb1(x)
        out = self.rdb2(out)
        out = self.rdb3(out)
        return out * 0.2 + x


class RRDBNet(nn.Module):
    def __init__(self, num_in_ch, num_out_ch, scale=4, num_feat=64, num_block=23, num_grow_ch=32):
        super(RRDBNet, self).__init__()
        self.scale = scale
        if scale == 2:
            num_in_ch = num_in_ch * 4
        elif scale == 1:
            num_in_ch = num_in_ch * 16
        self.conv_first = nn.Conv2d(num_in_ch, num_feat, 3, 1, 1)
        self.body = make_layer(RRDB, num_block, num_feat=num_feat, num_grow_ch=num_grow_ch)
        self.conv_body = nn.Conv2d(num_feat, num_feat, 3, 1, 1)
        # upsample
        self.conv_up1 = nn.Conv2d(num_feat, num_feat, 3, 1, 1)
        self.conv_up2 = nn.Conv2d(num_feat, num_feat, 3, 1, 1)
        self.conv_hr = nn.Conv2d(num_feat, num_feat, 3, 1, 1)
        self.conv_last = nn.Conv2d(num_feat, num_out_ch, 3, 1, 1)

        self.lrelu = nn.LeakyReLU(negative_slope=0.2, inplace=True)

    def forward(self, x):
        if self.scale == 2:
            feat = pixel_unshuffle(x, scale=2)
        elif self.scale == 1:
            feat = pixel_unshuffle(x, scale=4)
        else:
            feat = x
        feat = self.conv_first(feat)
        body_feat = self.conv_body(self.body(feat))
        feat = feat + body_feat
        # upsample
        feat = self.lrelu(self.conv_up1(F.interpolate(feat, scale_factor=2, mode='nearest')))
        feat = self.lrelu(self.conv_up2(F.interpolate(feat, scale_factor=2, mode='nearest')))
        out = self.conv_last(self.lrelu(self.conv_hr(feat)))
        return out


# ----------------- 新增辅助函数：适配权重到 3 通道输入/输出 -----------------
def strip_prefix_if_present(state_dict, prefix):
    """Remove prefix from keys if present (return new dict)."""
    new_sd = {}
    for k, v in state_dict.items():
        if k.startswith(prefix):
            new_sd[k[len(prefix):]] = v
        else:
            new_sd[k] = v
    return new_sd


def adapt_state_dict_to_3ch(state_dict, target_in_ch=3, target_out_ch=3):
    """
    针对 conv_first 和 conv_last 做通道裁剪/重复以适配 3->3 的输入输出。
    state_dict: 原始权重字典（torch tensors or numpy arrays）
    返回：新的 state_dict（修改了 conv_first/conv_last 的 tensor）
    """
    sd = dict(state_dict)  # shallow copy (tensors still shared, we replace entries)
    # 找到 conv_first 和 conv_last 的键（粗匹配）
    conv_first_key = next((k for k in sd.keys() if 'conv_first.weight' in k), None)
    conv_last_key = next((k for k in sd.keys() if 'conv_last.weight' in k), None)

    if conv_first_key is None or conv_last_key is None:
        print("警告: 未找到 conv_first 或 conv_last 的键，跳过通道适配。")
        return sd

    # 处理 conv_first.weight (shape: [out_ch, in_ch, k, k])
    w_first = sd[conv_first_key]
    if not isinstance(w_first, torch.Tensor):
        w_first = torch.as_tensor(w_first)
    orig_in = w_first.shape[1]
    if orig_in != target_in_ch:
        if orig_in > target_in_ch:
            new_w_first = w_first[:, :target_in_ch, :, :].clone()
        else:
            reps = (target_in_ch + orig_in - 1) // orig_in
            new_w_first = w_first.repeat(1, reps, 1, 1)[:, :target_in_ch, :, :].clone()
        sd[conv_first_key] = new_w_first
        print(f"Adapted {conv_first_key}: in_channels {orig_in} -> {target_in_ch}")

    # 处理 conv_last.weight (shape: [out_ch, in_ch, k, k])
    w_last = sd[conv_last_key]
    if not isinstance(w_last, torch.Tensor):
        w_last = torch.as_tensor(w_last)
    orig_out = w_last.shape[0]
    if orig_out != target_out_ch:
        if orig_out > target_out_ch:
            new_w_last = w_last[:target_out_ch, :, :, :].clone()
            # bias
            bias_key = conv_last_key.replace('weight', 'bias')
            if bias_key in sd:
                b = sd[bias_key]
                if not isinstance(b, torch.Tensor):
                    b = torch.as_tensor(b)
                sd[bias_key] = b[:target_out_ch].clone()
        else:
            reps = (target_out_ch + orig_out - 1) // orig_out
            new_w_last = w_last.repeat(reps, 1, 1, 1)[:target_out_ch, :, :, :].clone()
            bias_key = conv_last_key.replace('weight', 'bias')
            if bias_key in sd:
                b = sd[bias_key]
                if not isinstance(b, torch.Tensor):
                    b = torch.as_tensor(b)
                sd[bias_key] = b.repeat(reps)[:target_out_ch].clone()
        sd[conv_last_key] = new_w_last
        print(f"Adapted {conv_last_key}: out_channels {orig_out} -> {target_out_ch}")

    return sd


def analyze_model_weights(state_dict):
    """尽量从 state_dict 中推断模型参数（保留原函数主要输出）"""
    print("分析权重文件结构...")
    all_keys = list(state_dict.keys())
    print(f"权重文件包含 {len(all_keys)} 个参数")
    # 查找关键层
    conv_first_key = next((k for k in all_keys if 'conv_first.weight' in k), None)
    conv_last_key = next((k for k in all_keys if 'conv_last.weight' in k), None)
    conv_body_key = next((k for k in all_keys if 'conv_body.weight' in k), None)

    print(f"  conv_first: {conv_first_key}")
    print(f"  conv_last: {conv_last_key}")
    print(f"  conv_body: {conv_body_key}")

    if conv_first_key is None or conv_last_key is None:
        raise ValueError("无法找到 conv_first 或 conv_last 的权重键名，无法可靠推断模型参数。")

    conv_first_weight = state_dict[conv_first_key]
    conv_last_weight = state_dict[conv_last_key]
    if not isinstance(conv_first_weight, torch.Tensor):
        conv_first_weight = torch.as_tensor(conv_first_weight)
    if not isinstance(conv_last_weight, torch.Tensor):
        conv_last_weight = torch.as_tensor(conv_last_weight)

    num_in_ch = conv_first_weight.shape[1]
    num_out_ch = conv_last_weight.shape[0]
    num_feat = conv_first_weight.shape[0]

    # 计算 RRDB 块数量（尝试统计 rdb1.conv1.weight）
    num_blocks = len([k for k in all_keys if ('body.' in k or 'rdb' in k) and 'rdb1.conv1.weight' in k])
    if num_blocks == 0:
        # 备选：统计 body. 中的 RRDB 实例
        num_blocks = len(set([k.split('.')[1] for k in all_keys if k.startswith('body.') and 'rdb' in k]))

    # 上采样层推断
    up_block_keys = [k for k in all_keys if 'up_blocks.' in k or 'conv_up' in k or 'conv_up1' in k or 'conv_up2' in k]
    has_conv_up1 = any('conv_up1' in k for k in all_keys)
    has_conv_up2 = any('conv_up2' in k for k in all_keys)
    if up_block_keys:
        unique_up_blocks = set()
        for key in up_block_keys:
            if 'up_blocks.' in key:
                block_idx = key.split('.')[1]
                unique_up_blocks.add(block_idx)
        num_upsamples = len(unique_up_blocks) if unique_up_blocks else (2 if (has_conv_up1 and has_conv_up2) else 1)
    elif has_conv_up1 and has_conv_up2:
        num_upsamples = 2
    else:
        hr_keys = [k for k in all_keys if 'hr' in k.lower() or 'upsample' in k.lower()]
        num_upsamples = 1 if hr_keys else 1

    scale = 2 ** num_upsamples

    return {
        'num_in_ch': num_in_ch,
        'num_out_ch': num_out_ch,
        'num_feat': num_feat,
        'num_block': num_blocks if num_blocks > 0 else 23,
        'scale': scale,
        'conv_first_key': conv_first_key,
        'conv_last_key': conv_last_key,
        'conv_body_key': conv_body_key
    }


def create_3ch_model_and_load(state_dict):
    """
    基于 state_dict 尝试创建一个 3->3 的 RRDBNet，并尽力适配权重（裁剪/重复 conv_first/conv_last）。
    返回 (model, used_params)
    """
    try:
        # 有些 checkpoint key 带前缀（module. 等），如果直接无法匹配，我们尝试剥离常见前缀
        model_params = None
        for try_strip in [None, 'module.', 'net_g.', 'model.', 'generator.']:
            sd_try = state_dict if try_strip is None else strip_prefix_if_present(state_dict, try_strip)
            try:
                params = analyze_model_weights(sd_try)
                state_dict = sd_try
                model_params = params
                if try_strip is not None:
                    print(f"已尝试剥离前缀: {try_strip}")
                break
            except Exception as e:
                # 继续尝试其他前缀或原始 sd
                continue

        if model_params is None:
            raise RuntimeError("无法从 state_dict 中推断模型参数，使用默认参数创建 3 通道模型。")

        print("推断到的参数（用于构建 3->3 模型）:")
        print(model_params)
        # 强制目标输入输出为 3
        target_in_ch = 3
        target_out_ch = 3

        # 先对 state_dict 做适配（裁剪/重复 conv_first/conv_last）
        adapted_sd = adapt_state_dict_to_3ch(state_dict, target_in_ch, target_out_ch)

        # 构建模型（使用推断到的 num_feat, num_block, scale）
        model = RRDBNet(
            num_in_ch=target_in_ch,
            num_out_ch=target_out_ch,
            scale=model_params['scale'],
            num_feat=model_params['num_feat'],
            num_block=model_params['num_block'],
            num_grow_ch=32
        )

        # 处理常见前缀问题：如果 adapted_sd 的键没有与 model 的键匹配，尝试剥离前缀（module.）
        model_keys = set(model.state_dict().keys())
        if not any(k in model_keys for k in adapted_sd.keys()):
            for prefix in ['module.', 'net_g.', 'model.', 'generator.']:
                tmp = strip_prefix_if_present(adapted_sd, prefix)
                if any(k in model_keys for k in tmp.keys()):
                    adapted_sd = tmp
                    print(f"剥离前缀 '{prefix}' 后键与模型匹配。")
                    break

        # 尝试加载（非严格，以保留无法匹配的层）
        try:
            model.load_state_dict(adapted_sd, strict=False)
            print("权重以 strict=False 成功加载（部分层可能使用随机初始化）。")
        except Exception as e:
            print(f"加载 adapted state_dict 时报错: {e}")
            print("尝试直接用原始 state_dict 且 strict=False 加载（可能部分键被忽略）。")
            model.load_state_dict(state_dict, strict=False)

        return model, model_params

    except Exception as e:
        print(f"自动构建 3 通道模型失败: {e}")
        print("回落到默认 3->3 模型（num_feat=64, num_block=23, scale=4）。")
        default_params = {'num_in_ch': 3, 'num_out_ch': 3, 'num_feat': 64, 'num_block': 23, 'scale': 4}
        model = RRDBNet(3, 3, scale=4, num_feat=64, num_block=23, num_grow_ch=32)
        return model, default_params


# ----------------- 你的主流程（加载 checkpoint -> 创建 3ch 模型） -----------------
model_path = r"D:\Code\BasicSR-master\BasicSR-master\experiments\pretrained_models\ESRGAN\ESRGAN_SRx4.pth"
assert osp.exists(model_path), "Model path does not exist!"

device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
print(f"使用设备: {device}")

print("加载权重文件...")
checkpoint = torch.load(model_path, map_location='cpu')

if 'params_ema' in checkpoint:
    state_dict = checkpoint['params_ema']
    print("找到 EMA 权重")
elif 'params' in checkpoint:
    state_dict = checkpoint['params']
    print("找到普通权重")
else:
    state_dict = checkpoint
    print("使用根级权重")

# 创建 3 通道模型并尽力加载权重
model, model_params = create_3ch_model_and_load(state_dict)

model.eval()
model = model.to(device)

print('Model loaded. \nTesting...')


# ----------------- GDAL 读写、归一化、分块等函数（略微调整以确保 3 波段逻辑） -----------------
def read_tif_with_gdal(file_path):
    try:
        dataset = gdal.Open(file_path)
        if dataset is None:
            print(f"Error: Cannot open {file_path}")
            return None, None, None
        width = dataset.RasterXSize
        height = dataset.RasterYSize
        bands = dataset.RasterCount
        print(f"Image info: {width}x{height}, {bands} bands")
        img_data = []
        for i in range(1, bands + 1):
            band = dataset.GetRasterBand(i)
            band_data = band.ReadAsArray()
            img_data.append(band_data)
        img_data = np.stack(img_data, axis=0)
        geotransform = dataset.GetGeoTransform()
        projection = dataset.GetProjection()
        dataset = None
        return img_data, geotransform, projection
    except Exception as e:
        print(f"Error reading {file_path}: {str(e)}")
        return None, None, None


def save_tif_with_gdal(output_data, save_path, geotransform, projection, scale_factor=2):
    try:
        bands, height, width = output_data.shape
        new_geotransform = list(geotransform)
        new_geotransform[1] = geotransform[1] / scale_factor
        new_geotransform[5] = geotransform[5] / scale_factor
        driver = gdal.GetDriverByName('GTiff')
        out_dataset = driver.Create(save_path, width, height, bands, gdal.GDT_Float32)
        out_dataset.SetGeoTransform(new_geotransform)
        out_dataset.SetProjection(projection)
        for i in range(bands):
            out_band = out_dataset.GetRasterBand(i + 1)
            out_band.WriteArray(output_data[i])
            out_band.FlushCache()
        out_dataset = None
        print(f"Successfully saved: {save_path}")
    except Exception as e:
        print(f"Error saving {save_path}: {str(e)}")


def normalize_image(img_data):
    print(f"Original data range: min={np.min(img_data):.4f}, max={np.max(img_data):.4f}")
    print(f"Original data type: {img_data.dtype}")
    img_normalized = np.zeros_like(img_data, dtype=np.float32)
    for i in range(img_data.shape[0]):
        band_min = np.min(img_data[i])
        band_max = np.max(img_data[i])
        if band_max > band_min:
            img_normalized[i] = (img_data[i] - band_min) / (band_max - band_min)
        else:
            img_normalized[i] = np.zeros_like(img_data[i])
        print(f"  Band {i+1}: [{band_min:.4f}, {band_max:.4f}] -> [0, 1]")
    print(f"Normalized data range: min={np.min(img_normalized):.4f}, max={np.max(img_normalized):.4f}")
    return img_normalized


def denormalize_image(img_normalized, original_data):
    img_denormalized = np.zeros_like(img_normalized, dtype=original_data.dtype)
    for i in range(img_normalized.shape[0]):
        band_min = np.min(original_data[i])
        band_max = np.max(original_data[i])
        if band_max > band_min:
            img_denormalized[i] = img_normalized[i] * (band_max - band_min) + band_min
        else:
            img_denormalized[i] = np.full_like(img_normalized[i], band_min)
    return img_denormalized


def tile_process(img_data, model, device, tile_size=512, overlap=32):
    print(f"使用分块处理，tile_size={tile_size}, overlap={overlap}")
    bands, height, width = img_data.shape
    scale = model.scale
    output_h = height * scale
    output_w = width * scale
    output_img = np.zeros((bands, output_h, output_w), dtype=np.float32)
    stride = tile_size - overlap
    h_tiles = (height - overlap + stride - 1) // stride
    w_tiles = (width - overlap + stride - 1) // stride
    print(f"图像尺寸: {height}x{width}, 分块数量: {h_tiles}x{w_tiles}")
    for i in range(h_tiles):
        for j in range(w_tiles):
            start_h = i * stride
            start_w = j * stride
            end_h = min(start_h + tile_size, height)
            end_w = min(start_w + tile_size, width)
            tile = img_data[:, start_h:end_h, start_w:end_w]
            tile_tensor = torch.from_numpy(tile).float().unsqueeze(0).to(device)
            with torch.no_grad():
                output_tile_tensor = model(tile_tensor)
                output_tile = output_tile_tensor.squeeze(0).cpu().numpy()
            out_start_h = start_h * scale
            out_start_w = start_w * scale
            out_end_h = out_start_h + output_tile.shape[1]
            out_end_w = out_start_w + output_tile.shape[2]
            if i > 0:
                overlap_h = overlap * scale
                output_tile = output_tile[:, overlap_h//2:, :]
                out_start_h += overlap_h//2
            if j > 0:
                overlap_w = overlap * scale
                output_tile = output_tile[:, :, overlap_w//2:]
                out_start_w += overlap_w//2
            out_end_h = min(out_start_h + output_tile.shape[1], output_h)
            out_end_w = min(out_start_w + output_tile.shape[2], output_w)
            output_img[:, out_start_h:out_end_h, out_start_w:out_end_w] = \
                output_tile[:, :out_end_h-out_start_h, :out_end_w-out_start_w]
            print(f"完成分块 {i+1}/{h_tiles}, {j+1}/{w_tiles}")
    return output_img


# ----------------- 处理测试图像（强制 3 波段输入/输出） -----------------
test_img_folder = r"D:\AID Data Set\Airport\airport_349.jpg"
results_dir = r"D:\Code\BasicSR-master\results"
os.makedirs(results_dir, exist_ok=True)

if not glob.glob(test_img_folder):
    print(f"Warning: No files found at {test_img_folder}")
    print("Please check the file path.")
    exit()

idx = 0
expected_channels = 3  # 强制三波段输入/输出
for path in glob.glob(test_img_folder):
    idx += 1
    base = osp.splitext(osp.basename(path))[0]
    print(f"\n{'='*60}")
    print(f"{idx}: Processing {base}")
    print(f"{'='*60}")

    img_data, geotransform, projection = read_tif_with_gdal(path)
    if img_data is None:
        print(f"Warning: Image {path} could not be read, skipping...")
        continue

    orig_bands = img_data.shape[0]
    # 如果波段 >=3，直接取前三个波段；如果少于3，重复最后一波段补齐
    if orig_bands >= expected_channels:
        img_data = img_data[:expected_channels]
        if orig_bands > expected_channels:
            print(f"Image has {orig_bands} bands -> taking first {expected_channels} bands for inference.")
    else:
        to_add = expected_channels - orig_bands
        last_band = img_data[-1:]
        pad = np.repeat(last_band, to_add, axis=0)
        img_data = np.concatenate([img_data, pad], axis=0)
        print(f"Image has {orig_bands} bands -> padded to {expected_channels} by repeating last band.")

    print(f"Using image shape for inference: {img_data.shape}")

    # 保存用于反归一化的原始范围（仅前三个波段）
    original_img_data = img_data.copy()

    # 归一化
    img_normalized = normalize_image(img_data.astype(np.float32))

    _, height, width = img_normalized.shape
    tile_size = 512

    try:
        if height > tile_size or width > tile_size:
            print("图像较大，使用分块处理...")
            output = tile_process(img_normalized, model, device, tile_size)
        else:
            print("图像较小，使用整图处理...")
            img_tensor = torch.from_numpy(img_normalized).float().unsqueeze(0).to(device)
            print(f"Input tensor shape: {img_tensor.shape}")
            with torch.no_grad():
                print("Running inference...")
                output = model(img_tensor).data.squeeze().float().cpu().numpy()
                print(f"Raw output shape: {output.shape}")
                print("Inference completed successfully!")

        # 有可能模型输出通道数 !=3（例如某些模型输出4通道），此处只取前三通道作为最终输出
        if output.shape[0] >= expected_channels:
            output = output[:expected_channels]
            if output.shape[0] > expected_channels:
                print(f"Model produced {output.shape[0]} bands -> taking first {expected_channels} bands for saving.")
        else:
            # 如果输出通道数 < 3，重复最后一通道补齐
            out_bands = output.shape[0]
            to_add = expected_channels - out_bands
            last = output[-1:]
            pad = np.repeat(last, to_add, axis=0)
            output = np.concatenate([output, pad], axis=0)
            print(f"Model produced {out_bands} bands -> padded to {expected_channels} by repeating last band.")

        output = np.clip(output, 0, 1)
        print(f"Output data range after clipping: min={np.min(output):.4f}, max={np.max(output):.4f}")

        output_denormalized = denormalize_image(output, original_img_data)
        print(f"Denormalized output range: min={np.min(output_denormalized):.4f}, max={np.max(output_denormalized):.4f}")
        print(f"Denormalized output type: {output_denormalized.dtype}")

        save_path = osp.join(results_dir, f'{base}_sr.tif')
        save_tif_with_gdal(output_denormalized, save_path, geotransform, projection, scale_factor=model.scale)

        print(f"Processing completed for {base}")

    except Exception as e:
        print(f"Error during processing: {e}")
        import traceback
        traceback.print_exc()
        continue

print(f"\n{'='*60}")
print("All processing completed!")
print(f"Results saved in: {osp.abspath(results_dir)}")
print(f"{'='*60}")
