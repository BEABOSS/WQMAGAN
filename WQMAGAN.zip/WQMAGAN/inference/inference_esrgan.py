

import os
import os.path as osp
import torch
from torch import nn
from torch.nn import functional as F
import torch.nn.init as init
import numpy as np
import glob

from osgeo import gdal, osr
from basicsr.utils.registry import ARCH_REGISTRY
from basicsr.archs.arch_util import default_init_weights, make_layer, pixel_unshuffle

def dwt_haar(x):
    """
    Haar DWT by splitting even/odd indices.
    Input:
        x: (B, C, H, W)  -- H and W must be even
    Returns:
        LL, LH, HL, HH each (B, C, H//2, W//2)
    """
    B, C, H, W = x.shape
    assert H % 2 == 0 and W % 2 == 0, "H and W must be divisible by 2"
    x00 = x[..., 0::2, 0::2]
    x01 = x[..., 0::2, 1::2]
    x10 = x[..., 1::2, 0::2]
    x11 = x[..., 1::2, 1::2]
    # Haar forward (no sqrt scaling necessary if we keep consistent in inverse)
    LL = (x00 + x01 + x10 + x11) * 0.5
    LH = (x00 - x01 + x10 - x11) * 0.5
    HL = (x00 + x01 - x10 - x11) * 0.5
    HH = (x00 - x01 - x10 + x11) * 0.5
    return LL, LH, HL, HH

def idwt_haar(LL, LH, HL, HH):
    """
    Haar inverse DWT via placing components into even/odd indices.
    Inputs:
        LL, LH, HL, HH: (B, C, H2, W2)
    Returns:
        recon: (B, C, H2*2, W2*2)
    """
    B, C, H2, W2 = LL.shape
    H = H2 * 2
    W = W2 * 2
    # allocate
    recon = torch.zeros(B, C, H, W, device=LL.device, dtype=LL.dtype)
    # compute four subsamples according to inverse Haar formulas
    # solving the 4x4 linear system yields:
    # x00 = (LL + LH + HL + HH) / 2
    # x01 = (LL - LH + HL - HH) / 2
    # x10 = (LL + LH - HL - HH) / 2
    # x11 = (LL - LH - HL + HH) / 2
    x00 = (LL + LH + HL + HH) * 0.5
    x01 = (LL - LH + HL - HH) * 0.5
    x10 = (LL + LH - HL - HH) * 0.5
    x11 = (LL - LH - HL + HH) * 0.5
    recon[..., 0::2, 0::2] = x00
    recon[..., 0::2, 1::2] = x01
    recon[..., 1::2, 0::2] = x10
    recon[..., 1::2, 1::2] = x11
    return recon

# ---------------------------
# HighFreqBranch (修正 groups)
# ---------------------------
class HighFreqBranch(nn.Module):
    """
    High-frequency processing branch that works on DWT high-frequency components.
    Inputs are LH, HL, HH each (B, C, H2, W2).
    We concatenate to (B, 3C, H2, W2) and use grouped conv with groups=C so that
    each original channel's triplet (LH,HL,HH) is processed jointly, but channels are independent.
    """
    def __init__(self, C, num_layers=3):
        super(HighFreqBranch, self).__init__()
        in_ch = C * 3
        groups = C  # partition per original channel
        layers = []
        for i in range(num_layers):
            layers.append(nn.Conv2d(in_ch, in_ch, 3, 1, 1, groups=groups))
            layers.append(nn.LeakyReLU(0.2, inplace=True))
        layers.append(nn.Conv2d(in_ch, in_ch, 3, 1, 1, groups=groups))
        self.layers = nn.Sequential(*layers)
        # init
        for m in self.modules():
            if isinstance(m, nn.Conv2d):
                init.kaiming_normal_(m.weight, mode='fan_out', nonlinearity='leaky_relu')
                if m.bias is not None:
                    init.constant_(m.bias, 0)

    def forward(self, LH, HL, HH):
        # LH, HL, HH: (B, C, H2, W2)
        hf_input = torch.cat([LH, HL, HH], dim=1)  # (B, 3C, H2, W2)
        hf_output = self.layers(hf_input)
        C = LH.shape[1]
        LH_out = hf_output[:, :C, :, :]
        HL_out = hf_output[:, C:2*C, :, :]
        HH_out = hf_output[:, 2*C:3*C, :, :]
        return LH_out, HL_out, HH_out

# ---------------------------
# Adaptive Gate
# ---------------------------
class AdaptiveGate(nn.Module):
    def __init__(self, num_feat=64):
        super(AdaptiveGate, self).__init__()
        self.gate_conv = nn.Sequential(
            nn.Conv2d(num_feat * 2, num_feat // 4, 1),
            nn.LeakyReLU(0.2, inplace=True),
            nn.Conv2d(num_feat // 4, num_feat, 1),
            nn.Sigmoid()
        )
        # initialize gate bias to be negative so initial gate ~ small
        for m in self.gate_conv.modules():
            if isinstance(m, nn.Conv2d):
                if m.bias is not None:
                    init.constant_(m.bias, -2.0)

    def forward(self, feat, recon):
        # feat, recon: (B, C, H, W)
        combined = torch.cat([feat, recon], dim=1)
        gate = self.gate_conv(combined)  # (B, C, H, W)
        return gate

# ---------------------------
# RRDB & RDB (keep your earlier impl, minor name fixes)
# ---------------------------
class ResidualDenseBlock(nn.Module):
    """Residual Dense Block. Used in RRDB block in ESRGAN."""
    def __init__(self, num_feat=64, num_grow_ch=32):
        super(ResidualDenseBlock, self).__init__()
        self.conv1 = nn.Conv2d(num_feat, num_grow_ch, 3, 1, 1)
        self.conv2 = nn.Conv2d(num_feat + num_grow_ch, num_grow_ch, 3, 1, 1)
        self.conv3 = nn.Conv2d(num_feat + 2 * num_grow_ch, num_grow_ch, 3, 1, 1)
        self.conv4 = nn.Conv2d(num_feat + 3 * num_grow_ch, num_grow_ch, 3, 1, 1)
        self.conv5 = nn.Conv2d(num_feat + 4 * num_grow_ch, num_feat, 3, 1, 1)

        self.lrelu = nn.LeakyReLU(negative_slope=0.2, inplace=True)
        default_init_weights([self.conv1, self.conv2, self.conv3, self.conv4, self.conv5], 0.1)

    def forward(self, x):
        x1 = self.lrelu(self.conv1(x))
        x2 = self.lrelu(self.conv2(torch.cat((x, x1), 1)))
        x3 = self.lrelu(self.conv3(torch.cat((x, x1, x2), 1)))
        x4 = self.lrelu(self.conv4(torch.cat((x, x1, x2, x3), 1)))
        x5 = self.conv5(torch.cat((x, x1, x2, x3, x4), 1))
        return x5 * 0.2 + x

class RRDB(nn.Module):
    def __init__(self, num_feat, num_grow_ch=32):
        super(RRDB, self).__init__()
        self.rdb1 = ResidualDenseBlock(num_feat, num_grow_ch)
        self.rdb2 = ResidualDenseBlock(num_feat, num_grow_ch)
        self.rdb3 = ResidualDenseBlock(num_feat, num_grow_ch)

    def forward(self, x):
        out = self.rdb1(x)
        out = self.rdb2(out)
        out = self.rdb3(out)
        return out * 0.2 + x

# ---------------------------
# Enhanced RRDBNet
# ---------------------------
class EnhancedRRDBNet(nn.Module):
    """
    Enhanced RRDB-Net with DWT-based high-frequency processing
    """
    def __init__(self, num_in_ch, num_out_ch, scale=4, num_feat=64, num_block=23, num_grow_ch=32, alpha=0.1):
        super(EnhancedRRDBNet, self).__init__()
        self.scale = scale
        self.alpha = nn.Parameter(torch.tensor(alpha), requires_grad=True)

        # Handle different scales with pixel_unshuffle
        if scale == 2:
            num_in_ch = num_in_ch * 4
        elif scale == 1:
            num_in_ch = num_in_ch * 16

        # Shallow feature extraction
        self.conv_first = nn.Conv2d(num_in_ch, num_feat, 3, 1, 1)

        # Deep RRDB backbone
        self.body = make_layer(RRDB, num_block, num_feat=num_feat, num_grow_ch=num_grow_ch)
        self.conv_body = nn.Conv2d(num_feat, num_feat, 3, 1, 1)

        # High-frequency processing branch
        # note: pass C=num_feat so HighFreqBranch knows how to group
        self.high_freq_branch = HighFreqBranch(num_feat, num_layers=3)

        # Adaptive gating for frequency fusion
        self.adaptive_gate = AdaptiveGate(num_feat)
        
        # 添加 EnhancedSSRAM 模块来进一步增强特征
        self.enhanced_ssram = EnhancedSSRAM(num_feat)

        # Upsampling layers
        self.conv_up1 = nn.Conv2d(num_feat, num_feat, 3, 1, 1)
        self.conv_up2 = nn.Conv2d(num_feat, num_feat, 3, 1, 1)
        self.conv_hr = nn.Conv2d(num_feat, num_feat, 3, 1, 1)
        self.conv_last = nn.Conv2d(num_feat, num_out_ch, 3, 1, 1)

        self.lrelu = nn.LeakyReLU(negative_slope=0.2, inplace=True)

    def forward(self, x):
        # Handle different scales with pixel unshuffle
        if self.scale == 2:
            feat = pixel_unshuffle(x, scale=2)
        elif self.scale == 1:
            feat = pixel_unshuffle(x, scale=4)
        else:
            feat = x

        # Shallow feature extraction
        feat_shallow = self.conv_first(feat)  # (B, C, H, W)

        # Deep RRDB backbone
        body_feat = self.conv_body(self.body(feat_shallow))
        feat_main = feat_shallow + body_feat  # Feature F (B, C, H, W)

        # DWT decomposition on feature space
        LL, LH, HL, HH = dwt_haar(feat_main)  # each (B,C,H/2,W/2)

        # High-frequency processing on LH/HL/HH
        LH_recon, HL_recon, HH_recon = self.high_freq_branch(LH, HL, HH)

        # IDWT reconstruction -> recon has same spatial size as feat_main
        recon = idwt_haar(LL, LH_recon, HL_recon, HH_recon)  # (B, C, H, W)

        # Residual (high-frequency residual)
        R = recon - feat_main

        # Adaptive gating and fusion
        gate = self.adaptive_gate(feat_main, R)  # (B, C, H, W)
        feat_fused = feat_main + self.alpha * gate * R  # fused features
        
        # 在自适应门控融合之后添加 EnhancedSSRAM 进一步增强特征
        feat_enhanced = self.enhanced_ssram(feat_fused)

        # Upsampling (two times for scale=4)
        # Use functional.interpolate correctly; rename F->functional (we already import as F)
        up1 = F.interpolate(feat_enhanced, scale_factor=2, mode='nearest')
        up1 = self.lrelu(self.conv_up1(up1))
        up2 = F.interpolate(up1, scale_factor=2, mode='nearest')
        up2 = self.lrelu(self.conv_up2(up2))
        out = self.conv_last(self.lrelu(self.conv_hr(up2)))
        return out




class SpatialAttention(nn.Module):
    def __init__(self, channels):
        super(SpatialAttention, self).__init__()
        self.conv3 = nn.Conv2d(channels, channels, kernel_size=3, padding=1)
        self.conv5 = nn.Conv2d(channels, channels, kernel_size=5, padding=2)
        self.conv7 = nn.Conv2d(channels, channels, kernel_size=7, padding=3)
        self.conv1 = nn.Conv2d(channels * 3, channels, kernel_size=1)
        self.sigmoid = nn.Sigmoid()

    def forward(self, x):
        x3 = self.conv3(x)
        x5 = self.conv5(x)
        x7 = self.conv7(x)
        out = torch.cat([x3, x5, x7], dim=1)  # concat
        out = self.conv1(out)
        attn = self.sigmoid(out)
        return x * attn


class SpectralAttention(nn.Module):
    def __init__(self, channels):
        super(SpectralAttention, self).__init__()
        # 输入 shape: (B, C, H, W)，这里把 C 当成 "序列" 维度做1D卷积
        self.conv1 = nn.Conv1d(channels, channels, kernel_size=1, padding=0)
        self.conv3 = nn.Conv1d(channels, channels, kernel_size=3, padding=1)
        self.conv5 = nn.Conv1d(channels, channels, kernel_size=5, padding=2)
        self.conv1x1 = nn.Conv1d(channels * 3, channels, kernel_size=1)
        self.sigmoid = nn.Sigmoid()

    def forward(self, x):
        B, C, H, W = x.shape
        # reshape to (B, C, HW)
        x_1d = x.view(B, C, -1)

        x1 = self.conv1(x_1d)
        x3 = self.conv3(x_1d)
        x5 = self.conv5(x_1d)

        out = torch.cat([x1, x3, x5], dim=1)
        out = self.conv1x1(out)
        # 添加全局平均池化，确保空间维度变为1
        out = torch.mean(out, dim=2, keepdim=True)  # 变为(B, C, 1)
        attn = self.sigmoid(out).view(B, C, 1, 1)  # 现在可以正确reshape为(B, C, 1, 1)

        return x * attn


class FeedForward(nn.Module):
    def __init__(self, channels):
        super(FeedForward, self).__init__()
        self.ffn = nn.Sequential(
            nn.LeakyReLU(0.2, inplace=True),
            nn.Conv2d(channels, channels, kernel_size=1),
            nn.InstanceNorm2d(channels)
        )

    def forward(self, x):
        return self.ffn(x)


class EnhancedSSRAM(nn.Module):
    def __init__(self, channels):
        super(EnhancedSSRAM, self).__init__()
        self.conv_in = nn.Conv2d(channels, channels, 3, padding=1)
        
        # 多尺度空间注意力
        self.spatial_attn1 = SpatialAttention(channels)
        self.spatial_attn2 = SpatialAttention(channels)
        self.scale_attn = nn.Conv2d(channels * 2, channels, 1)
        
        # 频谱注意力
        self.spectral_attn = SpectralAttention(channels)
        
        # 改进的FFN，使用更宽的通道扩展
        self.ffn = nn.Sequential(
            nn.Conv2d(channels, channels * 2, 1),
            nn.LeakyReLU(0.2, inplace=True),
            nn.Conv2d(channels * 2, channels, 1),
            nn.InstanceNorm2d(channels)
        )
        
        self.conv_out = nn.Conv2d(channels, channels, 3, padding=1)
        
    def forward(self, x):
        identity = x
        out = self.conv_in(x)
        
        # 多尺度空间注意力
        spatial_out1 = self.spatial_attn1(out)
        spatial_out2 = self.spatial_attn2(F.avg_pool2d(out, kernel_size=2, stride=2))
        spatial_out2 = F.interpolate(spatial_out2, size=out.shape[2:], mode='bilinear', align_corners=False)
        spatial_out = self.scale_attn(torch.cat([spatial_out1, spatial_out2], dim=1))
        
        # 频谱注意力
        spectral_out = self.spectral_attn(out)
        
        # 融合注意力特征
        out = spatial_out + spectral_out
        
        # FFN
        out = self.ffn(out) + out
        
        # 输出卷积 + 残差
        out = self.conv_out(out)
        return out + identity
    
import numpy as np
import torch
import torch.nn.functional as F
from scipy import signal
from scipy.ndimage import convolve
import os
import os.path as osp
import glob
from osgeo import gdal

def create_sinc_filter(cutoff_freq=0.5, filter_size=21):
    """
    创建 sinc 低通滤波器
    
    Args:
        cutoff_freq: 截止频率 (0-1之间, 1表示奈奎斯特频率)
        filter_size: 滤波器大小 (应该是奇数)
    
    Returns:
        2D sinc 滤波器核
    """
    if filter_size % 2 == 0:
        filter_size += 1  # 确保是奇数
    
    # 创建1D sinc滤波器
    x = np.arange(filter_size) - filter_size // 2
    sinc_1d = np.sinc(2 * cutoff_freq * x)
    
    # 应用汉明窗减少振铃
    window = np.hamming(filter_size)
    sinc_1d *= window
    
    # 归一化
    sinc_1d /= np.sum(sinc_1d)
    
    # 创建2D滤波器 (可分离滤波器)
    sinc_2d = np.outer(sinc_1d, sinc_1d)
    
    return sinc_2d

def apply_sinc_filter_torch(image_tensor, cutoff_freq=0.5, filter_size=21):
    """
    使用PyTorch对图像张量应用sinc滤波
    
    Args:
        image_tensor: 输入张量 (B, C, H, W) 或 (C, H, W)
        cutoff_freq: 截止频率
        filter_size: 滤波器大小
    
    Returns:
        滤波后的张量
    """
    # 确保输入是4D张量
    if image_tensor.dim() == 3:
        image_tensor = image_tensor.unsqueeze(0)
        squeeze_output = True
    else:
        squeeze_output = False
    
    device = image_tensor.device
    dtype = image_tensor.dtype
    batch_size, channels, height, width = image_tensor.shape
    
    # 创建sinc滤波器
    sinc_kernel = create_sinc_filter(cutoff_freq, filter_size)
    sinc_kernel = torch.from_numpy(sinc_kernel).float().to(device)
    
    # 扩展滤波器以匹配通道数
    sinc_kernel = sinc_kernel.unsqueeze(0).unsqueeze(0)  # (1, 1, H, W)
    sinc_kernel = sinc_kernel.repeat(channels, 1, 1, 1)  # (C, 1, H, W)
    
    # 计算padding
    pad = filter_size // 2
    
    # 对每个通道分别应用滤波
    filtered_tensor = F.conv2d(
        image_tensor, 
        sinc_kernel, 
        padding=pad, 
        groups=channels
    )
    
    if squeeze_output:
        filtered_tensor = filtered_tensor.squeeze(0)
    
    return filtered_tensor.to(dtype)

def apply_sinc_filter_numpy(image_array, cutoff_freq=0.5, filter_size=21):
    """
    使用NumPy对图像数组应用sinc滤波
    
    Args:
        image_array: 输入数组 (C, H, W) 或 (H, W)
        cutoff_freq: 截止频率
        filter_size: 滤波器大小
    
    Returns:
        滤波后的数组
    """
    # 创建sinc滤波器
    sinc_kernel = create_sinc_filter(cutoff_freq, filter_size)
    
    if image_array.ndim == 2:
        # 单通道图像
        filtered_array = convolve(image_array, sinc_kernel, mode='reflect')
    else:
        # 多通道图像
        filtered_array = np.zeros_like(image_array)
        for i in range(image_array.shape[0]):
            filtered_array[i] = convolve(image_array[i], sinc_kernel, mode='reflect')
    
    return filtered_array

def adaptive_sinc_filter(image_data, method='auto', cutoff_freq=0.5, filter_size=21):
    """
    自适应选择sinc滤波方法
    
    Args:
        image_data: 图像数据 (torch.Tensor 或 numpy.ndarray)
        method: 滤波方法 ('torch', 'numpy', 'auto')
        cutoff_freq: 截止频率
        filter_size: 滤波器大小
    
    Returns:
        滤波后的图像数据
    """
    if method == 'auto':
        # 根据数据类型自动选择方法
        if isinstance(image_data, torch.Tensor):
            method = 'torch'
        else:
            method = 'numpy'
    
    if method == 'torch':
        if isinstance(image_data, np.ndarray):
            # 转换为torch tensor
            original_type = 'numpy'
            image_tensor = torch.from_numpy(image_data).float()
            if torch.cuda.is_available():
                image_tensor = image_tensor.cuda()
        else:
            original_type = 'torch'
            image_tensor = image_data
        
        # 应用滤波
        filtered_tensor = apply_sinc_filter_torch(image_tensor, cutoff_freq, filter_size)
        
        if original_type == 'numpy':
            return filtered_tensor.cpu().numpy()
        else:
            return filtered_tensor
    
    else:  # numpy method
        if isinstance(image_data, torch.Tensor):
            image_array = image_data.cpu().numpy()
            original_type = 'torch'
        else:
            image_array = image_data
            original_type = 'numpy'
        
        # 应用滤波
        filtered_array = apply_sinc_filter_numpy(image_array, cutoff_freq, filter_size)
        
        if original_type == 'torch':
            return torch.from_numpy(filtered_array).to(image_data.device)
        else:
            return filtered_array

def analyze_model_weights(state_dict):
    """分析权重文件并推断模型参数"""
    print("分析权重文件结构...")
    
    # 打印所有键名以便调试
    all_keys = list(state_dict.keys())
    print(f"权重文件包含 {len(all_keys)} 个参数")
    print("前10个键名:")
    for i, key in enumerate(all_keys[:10]):
        print(f"  {i+1}: {key}")
    
    # 查找关键层的权重
    conv_first_key = None
    conv_last_key = None
    conv_body_key = None
    
    for key in all_keys:
        if 'conv_first.weight' in key:
            conv_first_key = key
        elif 'conv_last.weight' in key:
            conv_last_key = key
        elif 'conv_body.weight' in key:
            conv_body_key = key
    
    print(f"\n找到的关键层:")
    print(f"  conv_first: {conv_first_key}")
    print(f"  conv_last: {conv_last_key}")
    print(f"  conv_body: {conv_body_key}")
    
    if not conv_first_key or not conv_last_key:
        raise ValueError("无法找到conv_first或conv_last层的权重")
    
    # 从权重形状推断参数
    conv_first_weight = state_dict[conv_first_key]
    conv_last_weight = state_dict[conv_last_key]
    
    num_in_ch = conv_first_weight.shape[1]  # 输入通道
    num_out_ch = conv_last_weight.shape[0]  # 输出通道
    num_feat = conv_first_weight.shape[0]   # 特征通道数
    
    # 计算RRDB块数量
    num_blocks = len([k for k in all_keys if k.startswith('body.') and 'rdb1.conv1.weight' in k])
    
    # 改进的缩放因子推断逻辑
    up_block_keys = [k for k in all_keys if 'up_blocks.' in k or 'upconv' in k or 'upsample' in k]
    # 检查是否有conv_up1和conv_up2层，这是4倍超分辨率模型的特征
    has_conv_up1 = any('conv_up1' in k for k in all_keys)
    has_conv_up2 = any('conv_up2' in k for k in all_keys)
    
    if up_block_keys:
        # 方法1: 通过up_blocks数量推断
        unique_up_blocks = set()
        for key in up_block_keys:
            if 'up_blocks.' in key:
                block_idx = key.split('.')[1]
                unique_up_blocks.add(block_idx)
        num_upsamples = len(unique_up_blocks)
    elif has_conv_up1 and has_conv_up2:
        # 如果同时有conv_up1和conv_up2，这很可能是4倍超分辨率模型
        print("检测到conv_up1和conv_up2层,假设为4倍超分辨率")
        num_upsamples = 2  # 4倍超分辨率需要2次上采样
    else:
        # 方法2: 如果没有找到up_blocks，尝试其他方法
        # 检查是否有HRConv或其他上采样相关的层
        hr_keys = [k for k in all_keys if 'hr' in k.lower() or 'upsample' in k.lower()]
        if hr_keys:
            print("检测到HR相关层,默认使用2倍超分辨率")
            num_upsamples = 1
        else:
            print("无法确定上采样层,默认使用2倍超分辨率")
            num_upsamples = 1
    
    scale = 2 ** num_upsamples
    
    return {
        'num_in_ch': num_in_ch,
        'num_out_ch': num_out_ch,
        'num_feat': num_feat,
        'num_block': num_blocks,
        'scale': scale,
        'conv_first_key': conv_first_key,
        'conv_last_key': conv_last_key,
        'conv_body_key': conv_body_key
    }

def create_model_from_weights(state_dict):
    """根据权重文件创建匹配的模型"""
    try:
        params = analyze_model_weights(state_dict)
        
        print(f"\n推断的模型参数:")
        print(f"  num_in_ch: {params['num_in_ch']}")
        print(f"  num_out_ch: {params['num_out_ch']}")
        print(f"  num_feat: {params['num_feat']}")
        print(f"  num_block: {params['num_block']}")
        print(f"  scale: {params['scale']}")
        
        # 计算实际的输入通道数，需要考虑scale对num_in_ch的影响
        original_num_in_ch = params['num_in_ch']
        adjusted_num_in_ch = original_num_in_ch
        
        # 如果scale=2，num_in_ch会被乘以4；如果scale=1，num_in_ch会被乘以16
        # 因此我们需要反向计算，以确保模型使用正确的输入通道数
        if params['scale'] == 2:
            adjusted_num_in_ch = original_num_in_ch // 4
        elif params['scale'] == 1:
            adjusted_num_in_ch = original_num_in_ch // 16
        
        print(f"  调整后的num_in_ch: {adjusted_num_in_ch}")
        
        # 创建模型时使用调整后的num_in_ch
        model = EnhancedRRDBNet(
            num_in_ch=adjusted_num_in_ch,
            num_out_ch=params['num_out_ch'],
            num_feat=params['num_feat'],
            num_block=params['num_block'],
            num_grow_ch=32,
            scale=params['scale']
        )
        
        return model, params
        
    except Exception as e:
        print(f"自动推断失败: {e}")
        print("使用默认参数创建模型...")
        
        # 使用默认参数
        default_params = {
            'num_in_ch': 3,
            'num_out_ch': 3,
            'num_feat': 64,
            'num_block': 23,
            'scale': 4  # 这里也可以根据您的需求修改为默认4倍
        }
        
        model = EnhancedRRDBNet(**default_params)
        return model, default_params

# Sinc滤波配置参数
SINC_FILTER_CONFIG = {
    'enabled': True,          # 是否启用sinc滤波
    'cutoff_freq': 0.3,       # 截止频率 (0.3-0.6之间效果较好)
    'filter_size': 21,        # 滤波器大小 (奇数，15-25之间)
    'method': 'torch',        # 滤波方法 ('torch', 'numpy', 'auto')
    'apply_stage': 'output'   # 应用阶段 ('output', 'both')
}

# 模型路径
model_path = r"D:\net_g_latest.pth"
# 如果模型路径不存在，抛出错误
assert osp.exists(model_path), "Model path does not exist!"

# 设备设置
device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
print(f"使用设备: {device}")

# 测试图像文件夹或单个文件路径
test_img_folder = r"C:\Users\22174\Desktop\test\shandong_uint8_0_4.tif"

# 创建结果目录
results_dir = 'results'
os.makedirs(results_dir, exist_ok=True)

# 打印Sinc滤波配置
if SINC_FILTER_CONFIG['enabled']:
    print(f"\n{'='*60}")
    print("Sinc滤波配置:")
    print(f"  启用状态: {SINC_FILTER_CONFIG['enabled']}")
    print(f"  截止频率: {SINC_FILTER_CONFIG['cutoff_freq']}")
    print(f"  滤波器大小: {SINC_FILTER_CONFIG['filter_size']}")
    print(f"  滤波方法: {SINC_FILTER_CONFIG['method']}")
    print(f"  应用阶段: {SINC_FILTER_CONFIG['apply_stage']}")
    print(f"{'='*60}")

# 加载权重文件
print("加载权重文件...")
checkpoint = torch.load(model_path, map_location='cpu')

# 检查权重文件结构并选择正确的权重
if 'params_ema' in checkpoint:
    state_dict = checkpoint['params_ema']
    print("找到 EMA 权重")
elif 'params' in checkpoint:
    state_dict = checkpoint['params']
    print("找到普通权重")
else:
    state_dict = checkpoint
    print("使用根级权重")

# 创建模型
model, model_params = create_model_from_weights(state_dict)

# 加载权重
print(f'Loading model from {model_path}')
try:
    model.load_state_dict(state_dict, strict=True)
    print("模型权重加载成功!")
except Exception as e:
    print(f"严格加载失败: {e}")
    print("尝试非严格加载...")
    model.load_state_dict(state_dict, strict=False)
    print("非严格加载完成!")

model.eval()
model = model.to(device)

print('Model path {:s}. \nTesting...'.format(model_path))

def read_tif_with_gdal(file_path):
    """
    使用GDAL读取TIF文件
    返回：图像数据(numpy数组), 地理变换参数, 投影信息
    """
    try:
        dataset = gdal.Open(file_path)
        if dataset is None:
            print(f"Error: Cannot open {file_path}")
            return None, None, None

        # 获取图像信息
        width = dataset.RasterXSize
        height = dataset.RasterYSize
        bands = dataset.RasterCount

        print(f"Image info: {width}x{height}, {bands} bands")

        # 读取所有波段数据
        img_data = []
        for i in range(1, bands + 1):
            band = dataset.GetRasterBand(i)
            band_data = band.ReadAsArray()
            img_data.append(band_data)

        img_data = np.stack(img_data, axis=0)  # Shape: (bands, height, width)

        # 获取地理信息
        geotransform = dataset.GetGeoTransform()
        projection = dataset.GetProjection()

        dataset = None  # 关闭数据集

        return img_data, geotransform, projection

    except Exception as e:
        print(f"Error reading {file_path}: {str(e)}")
        return None, None, None

def save_tif_with_gdal(output_data, save_path, geotransform, projection, scale_factor=2):
    """
    使用GDAL保存TIF文件，保留地理信息
    """
    try:
        # 获取输出数据的形状
        bands, height, width = output_data.shape

        # 调整地理变换参数以适应超分辨率
        new_geotransform = list(geotransform)
        new_geotransform[4] = geotransform[4] / scale_factor  # 像素大小X方向
        new_geotransform[4] = geotransform[4] / scale_factor  # 像素大小Y方向

        # 创建输出数据集
        driver = gdal.GetDriverByName('GTiff')
        out_dataset = driver.Create(save_path, width, height, bands, gdal.GDT_Float32)

        # 设置地理变换和投影
        out_dataset.SetGeoTransform(new_geotransform)
        out_dataset.SetProjection(projection)

        # 写入每个波段
        for i in range(bands):
            out_band = out_dataset.GetRasterBand(i + 1)
            out_band.WriteArray(output_data[i])
            out_band.FlushCache()

        out_dataset = None  # 关闭数据集
        print(f"Successfully saved: {save_path}")

    except Exception as e:
        print(f"Error saving {save_path}: {str(e)}")

def normalize_image(img_data):
    """
    归一化图像数据到[0,1]范围
    """
    # 检查数据类型和范围
    print(f"Original data range: min={np.min(img_data):.4f}, max={np.max(img_data):.4f}")
    print(f"Original data type: {img_data.dtype}")

    # 逐波段归一化
    img_normalized = np.zeros_like(img_data, dtype=np.float32)
    for i in range(img_data.shape[0]):
        band_min = np.min(img_data[i])
        band_max = np.max(img_data[i])
        if band_max > band_min:
            img_normalized[i] = (img_data[i] - band_min) / (band_max - band_min)
        else:
            img_normalized[i] = np.zeros_like(img_data[i])
        print(f"  Band {i+1}: [{band_min:.4f}, {band_max:.4f}] -> [0, 1]")

    print(f"Normalized data range: min={np.min(img_normalized):.4f}, max={np.max(img_normalized):.4f}")
    return img_normalized

def denormalize_image(img_normalized, original_data):
    """
    将归一化后的图像恢复到原始数据范围
    """
    img_denormalized = np.zeros_like(img_normalized, dtype=original_data.dtype)
    for i in range(img_normalized.shape[0]):
        band_min = np.min(original_data[i])
        band_max = np.max(original_data[i])
        if band_max > band_min:
            img_denormalized[i] = img_normalized[i] * (band_max - band_min) + band_min
        else:
            img_denormalized[i] = np.full_like(img_normalized[i], band_min)

    return img_denormalized

def tile_process(img_data, model, device, tile_size=512, overlap=32):
    """
    分块处理大图像 (带sinc滤波支持)
    """
    print(f"使用分块处理，tile_size={tile_size}, overlap={overlap}")
    
    bands, height, width = img_data.shape
    scale = model.scale
    
    # 输出图像尺寸
    output_h = height * scale
    output_w = width * scale
    output_img = np.zeros((bands, output_h, output_w), dtype=np.float32)
    
    # 计算分块数量
    stride = tile_size - overlap
    h_tiles = (height - overlap + stride - 1) // stride
    w_tiles = (width - overlap + stride - 1) // stride
    
    print(f"图像尺寸: {height}x{width}, 分块数量: {h_tiles}x{w_tiles}")
    
    for i in range(h_tiles):
        for j in range(w_tiles):
            # 计算当前块的位置
            start_h = i * stride
            start_w = j * stride
            end_h = min(start_h + tile_size, height)
            end_w = min(start_w + tile_size, width)
            
            # 提取当前块
            tile = img_data[:, start_h:end_h, start_w:end_w]
            
            # 转换为tensor并推理
            tile_tensor = torch.from_numpy(tile).float().unsqueeze(0).to(device)
            
            with torch.no_grad():
                output_tile_tensor = model(tile_tensor)
                
                # 对输出应用sinc滤波
                if SINC_FILTER_CONFIG['enabled'] and SINC_FILTER_CONFIG['apply_stage'] in ['output', 'both']:
                    print(f"对分块 ({i+1},{j+1}) 输出应用Sinc滤波...")
                    output_tile_tensor = adaptive_sinc_filter(
                        output_tile_tensor.squeeze(0),
                        method=SINC_FILTER_CONFIG['method'],
                        cutoff_freq=SINC_FILTER_CONFIG['cutoff_freq'],
                        filter_size=SINC_FILTER_CONFIG['filter_size']
                    ).unsqueeze(0)
                
                output_tile = output_tile_tensor.squeeze(0).cpu().numpy()
            
            # 计算输出位置
            out_start_h = start_h * scale
            out_start_w = start_w * scale
            out_end_h = out_start_h + output_tile.shape[1]
            out_end_w = out_start_w + output_tile.shape[2]
            
            # 处理边界重叠
            if i > 0:  # 不是第一行
                overlap_h = overlap * scale
                output_tile = output_tile[:, overlap_h//2:, :]
                out_start_h += overlap_h//2
                
            if j > 0:  # 不是第一列
                overlap_w = overlap * scale
                output_tile = output_tile[:, :, overlap_w//2:]
                out_start_w += overlap_w//2
            
            # 放置到输出图像中
            out_end_h = min(out_start_h + output_tile.shape[1], output_h)
            out_end_w = min(out_start_w + output_tile.shape[2], output_w)
            
            output_img[:, out_start_h:out_end_h, out_start_w:out_end_w] = \
                output_tile[:, :out_end_h-out_start_h, :out_end_w-out_start_w]
            
            print(f"完成分块 {i+1}/{h_tiles}, {j+1}/{w_tiles}")
    
    return output_img

# 检查是否可以找到测试文件
if not glob.glob(test_img_folder):
    print(f"Warning: No files found at {test_img_folder}")
    print("Please check the file path.")
    exit()

idx = 0
# 遍历测试图像
for path in glob.glob(test_img_folder):
    idx += 1
    base = osp.splitext(osp.basename(path))[0]
    print(f"\n{'='*60}")
    print(f"{idx}: Processing {base}")
    print(f"{'='*60}")

    # 使用GDAL读取TIF文件
    img_data, geotransform, projection = read_tif_with_gdal(path)

    if img_data is None:
        print(f"Warning: Image {path} could not be read, skipping...")
        continue

    # 检查波段数是否匹配
    expected_channels = model_params['num_in_ch']
    if img_data.shape[0] != expected_channels:
        print(f"Warning: Image {path} has {img_data.shape[0]} bands, but model expects {expected_channels} bands")
        
        # 尝试调整通道数
        if img_data.shape[0] == 1 and expected_channels == 3:
            # 灰度图转RGB
            img_data = np.repeat(img_data, 3, axis=0)
            print(f"转换为3通道图像")
        elif img_data.shape[0] == 3 and expected_channels == 1:
            # RGB转灰度
            img_data = np.mean(img_data, axis=0, keepdims=True)
            print(f"转换为单通道图像")
        elif img_data.shape[0] == 3 and expected_channels == 4:
            # 为3波段图像添加空波段以适配4波段模型
            # 创建一个与原图像形状相同的零数组，但增加一个波段
            empty_band = np.zeros((1, img_data.shape[1], img_data.shape[2]), dtype=img_data.dtype)
            # 将原图像和空波段连接
            img_data = np.concatenate([img_data, empty_band], axis=0)
            print(f"为3波段图像添加空波段，转换为4通道图像")
        elif img_data.shape[0] > expected_channels:
            # 裁剪多余通道
            img_data = img_data[:expected_channels]
            print(f"裁剪到{expected_channels}通道")
        else:
            print(f"无法处理通道数不匹配，跳过...")
            continue

    print(f"Original image shape: {img_data.shape}")

    # 保存原始数据用于反归一化
    original_img_data = img_data.copy()

    # 图像预处理 - 归一化到[0,1]
    img_normalized = normalize_image(img_data.astype(np.float32))

    # 在输入上应用sinc滤波 (如果配置为both)
    if SINC_FILTER_CONFIG['enabled'] and SINC_FILTER_CONFIG['apply_stage'] == 'both':
        print("对输入图像应用Sinc滤波...")
        img_normalized = adaptive_sinc_filter(
            img_normalized,
            method=SINC_FILTER_CONFIG['method'],
            cutoff_freq=SINC_FILTER_CONFIG['cutoff_freq'],
            filter_size=SINC_FILTER_CONFIG['filter_size']
        )

    # 判断是否需要分块处理
    _, height, width = img_normalized.shape
    tile_size = 512  # 可根据显存大小调整
    
    try:
        if height > tile_size or width > tile_size:
            print("图像较大，使用分块处理...")
            output = tile_process(img_normalized, model, device, tile_size)
        else:
            print("图像较小，使用整图处理...")
            # 转换为PyTorch张量
            img_tensor = torch.from_numpy(img_normalized).float().unsqueeze(0)
            img_tensor = img_tensor.to(device)

            print(f"Input tensor shape: {img_tensor.shape}")
            print(f"Input tensor device: {img_tensor.device}")

            with torch.no_grad():
                # 模型推理
                print("Running inference...")
                output_tensor = model(img_tensor)
                
                # 对输出应用sinc滤波
                if SINC_FILTER_CONFIG['enabled'] and SINC_FILTER_CONFIG['apply_stage'] in ['output', 'both']:
                    print("对输出图像应用Sinc滤波...")
                    output_tensor = adaptive_sinc_filter(
                        output_tensor.squeeze(0),
                        method=SINC_FILTER_CONFIG['method'],
                        cutoff_freq=SINC_FILTER_CONFIG['cutoff_freq'],
                        filter_size=SINC_FILTER_CONFIG['filter_size']
                    ).unsqueeze(0)
                
                output = output_tensor.data.squeeze().float().cpu().numpy()
                print(f"Output tensor shape: {output.shape}")
                print("Inference completed successfully!")

        # 确保输出在[0,1]范围内
        output = np.clip(output, 0, 1)
        print(f"Output data range after clipping: min={np.min(output):.4f}, max={np.max(output):.4f}")

        # 反归一化到原始数据范围
        output_denormalized = denormalize_image(output, original_img_data)
        print(f"Denormalized output range: min={np.min(output_denormalized):.4f}, max={np.max(output_denormalized):.4f}")
        print(f"Denormalized output type: {output_denormalized.dtype}")

        # 保存结果 (根据是否使用sinc滤波添加后缀)
        if SINC_FILTER_CONFIG['enabled']:
            save_path = osp.join(results_dir, f'{base}_sr_sinc.tif')
            print(f"Sinc滤波已应用 - 截止频率: {SINC_FILTER_CONFIG['cutoff_freq']}, 滤波器大小: {SINC_FILTER_CONFIG['filter_size']}")
        else:
            save_path = osp.join(results_dir, f'{base}_sr.tif')
        
        save_tif_with_gdal(output_denormalized, save_path, geotransform, projection, scale_factor=model_params['scale'])

        print(f"Processing completed for {base}")
        
        # 可选：保存滤波参数信息到文本文件
        if SINC_FILTER_CONFIG['enabled']:
            info_path = osp.join(results_dir, f'{base}_sr_sinc_info.txt')
            with open(info_path, 'w') as f:
                f.write(f"Sinc滤波参数信息:\n")
                f.write(f"启用状态: {SINC_FILTER_CONFIG['enabled']}\n")
                f.write(f"截止频率: {SINC_FILTER_CONFIG['cutoff_freq']}\n")
                f.write(f"滤波器大小: {SINC_FILTER_CONFIG['filter_size']}\n")
                f.write(f"滤波方法: {SINC_FILTER_CONFIG['method']}\n")
                f.write(f"应用阶段: {SINC_FILTER_CONFIG['apply_stage']}\n")
                f.write(f"模型缩放因子: {model_params['scale']}\n")
                f.write(f"原始图像形状: {original_img_data.shape}\n")
                f.write(f"输出图像形状: {output.shape}\n")
        
    except Exception as e:
        print(f"Error during processing: {e}")
        import traceback
        traceback.print_exc()
        continue

print(f"\n{'='*60}")
print("All processing completed!")
print(f"Results saved in: {osp.abspath(results_dir)}")
if SINC_FILTER_CONFIG['enabled']:
    print("注意: 使用了Sinc滤波去除GAN伪影")
    print(f"滤波参数 - 截止频率: {SINC_FILTER_CONFIG['cutoff_freq']}, 滤波器大小: {SINC_FILTER_CONFIG['filter_size']}")
print(f"{'='*60}")

# 使用说明和参数调优建议
print(f"\n{'='*60}")
print("Sinc滤波参数调优建议:")
print("1. cutoff_freq (截止频率):")
print("   - 范围: 0.2-0.8")
print("   - 0.3-0.4: 强烈去伪影，可能轻微模糊")
print("   - 0.4-0.5: 平衡去伪影和细节保持 (推荐)")
print("   - 0.5-0.6: 温和去伪影，保持更多细节")
print("")
print("2. filter_size (滤波器大小):")
print("   - 范围: 15-31 (奇数)")
print("   - 15-19: 计算快，去伪影效果适中")
print("   - 21-25: 平衡性能和效果 (推荐)")
print("   - 27-31: 更好的去伪影效果，计算稍慢")
print("")
print("3. apply_stage (应用阶段):")
print("   - 'output': 仅对模型输出应用 (推荐)")
print("   - 'both': 对输入和输出都应用 (可能过度平滑)")
print("")
print("4. method (滤波方法):")
print("   - 'torch': GPU加速，适合大图像")
print("   - 'numpy': CPU处理，内存友好")
print("   - 'auto': 自动选择")
print(f"{'='*60}")