import argparse
import torch
import numpy as np
import os
import os.path as osp
import glob
from osgeo import gdal, osr
from basicsr.archs.rfdb_arch import RFDN


def read_tif_with_gdal(file_path):
    """
    使用GDAL读取TIF文件
    返回：图像数据(numpy数组), 地理变换参数, 投影信息
    """
    try:
        dataset = gdal.Open(file_path)
        if dataset is None:
            print(f"Error: Cannot open {file_path}")
            return None, None, None

        # 获取图像信息
        width = dataset.RasterXSize
        height = dataset.RasterYSize
        bands = dataset.RasterCount

        print(f"Image info: {width}x{height}, {bands} bands")

        # 读取所有波段数据
        img_data = []
        for i in range(1, bands + 1):
            band = dataset.GetRasterBand(i)
            band_data = band.ReadAsArray()
            img_data.append(band_data)

        img_data = np.stack(img_data, axis=0)  # Shape: (bands, height, width)

        # 获取地理信息
        geotransform = dataset.GetGeoTransform()
        projection = dataset.GetProjection()

        dataset = None  # 关闭数据集

        return img_data, geotransform, projection

    except Exception as e:
        print(f"Error reading {file_path}: {str(e)}")
        return None, None, None


def save_tif_with_gdal(output_data, save_path, geotransform, projection, scale_factor=4):
    """
    使用GDAL保存TIF文件，保留地理信息
    """
    try:
        # 获取输出数据的形状
        bands, height, width = output_data.shape

        # 调整地理变换参数以适应超分辨率
        new_geotransform = list(geotransform)
        new_geotransform[4] = geotransform[4] / scale_factor  # 像素大小X方向
        new_geotransform[4] = geotransform[4] / scale_factor  # 像素大小Y方向

        # 创建输出数据集
        driver = gdal.GetDriverByName('GTiff')
        out_dataset = driver.Create(save_path, width, height, bands, gdal.GDT_Float32)

        # 设置地理变换和投影
        out_dataset.SetGeoTransform(new_geotransform)
        out_dataset.SetProjection(projection)

        # 写入每个波段
        for i in range(bands):
            out_band = out_dataset.GetRasterBand(i + 1)
            out_band.WriteArray(output_data[i])
            out_band.FlushCache()

        out_dataset = None  # 关闭数据集
        print(f"Successfully saved: {save_path}")

    except Exception as e:
        print(f"Error saving {save_path}: {str(e)}")


def normalize_image(img_data):
    """
    归一化图像数据到[0,1]范围
    """
    # 检查数据类型和范围
    print(f"Original data range: min={np.min(img_data):.4f}, max={np.max(img_data):.4f}")
    print(f"Original data type: {img_data.dtype}")

    # 逐波段归一化
    img_normalized = np.zeros_like(img_data, dtype=np.float32)
    for i in range(img_data.shape[0]):
        band_min = np.min(img_data[i])
        band_max = np.max(img_data[i])
        if band_max > band_min:
            img_normalized[i] = (img_data[i] - band_min) / (band_max - band_min)
        else:
            img_normalized[i] = np.zeros_like(img_data[i])
        print(f"  Band {i+1}: [{band_min:.4f}, {band_max:.4f}] -> [0, 1]")

    print(f"Normalized data range: min={np.min(img_normalized):.4f}, max={np.max(img_normalized):.4f}")
    return img_normalized


def denormalize_image(img_normalized, original_data):
    """
    将归一化后的图像恢复到原始数据范围
    """
    img_denormalized = np.zeros_like(img_normalized, dtype=original_data.dtype)
    for i in range(img_normalized.shape[0]):
        band_min = np.min(original_data[i])
        band_max = np.max(original_data[i])
        if band_max > band_min:
            img_denormalized[i] = img_normalized[i] * (band_max - band_min) + band_min
        else:
            img_denormalized[i] = np.full_like(img_normalized[i], band_min)

    return img_denormalized


def main():
    parser = argparse.ArgumentParser(description='RFDN推理脚本')
    parser.add_argument('--input', type=str,default=r"C:\Users\22174\Desktop\test\shandong_uint8_0_4.tif",  help='输入图像路径')
    parser.add_argument('--output', type=str, default=r"D:\Code\BasicSR-master\results", help='输出保存路径')
    parser.add_argument('--model_path', type=str,  default=r"D:\net_g_340000.pth", help='模型权重路径')
    parser.add_argument('--scale', type=int, default=4, help='上采样倍数')
    parser.add_argument('--device', type=str, default='cuda', help='设备 (cuda or cpu)')
    args = parser.parse_args()

    # 创建输出目录
    os.makedirs(args.output, exist_ok=True)

    # 初始化模型
    model = RFDN(in_nc=4, nf=50, num_modules=4, out_nc=4, upscale=args.scale)
    model.load_state_dict(torch.load(args.model_path)['params_ema'], strict=True)
    model.eval()
    
    if args.device == 'cuda' and torch.cuda.is_available():
        model = model.cuda()
        device = torch.device('cuda')
    else:
        device = torch.device('cpu')
    
    print(f"模型已加载到 {device} 设备")

    # 处理输入图像
    img_data, geotransform, projection = read_tif_with_gdal(args.input)
    if img_data is None:
        raise FileNotFoundError(f"无法读取图像文件: {args.input}")
    
    # 检查波段数是否匹配
    expected_channels = 4
    if img_data.shape[0] != expected_channels:
        print(f"Warning: Image {args.input} has {img_data.shape[0]} bands, but model expects {expected_channels} bands")
        
        # 尝试调整通道数
        if img_data.shape[0] == 1 and expected_channels == 3:
            # 灰度图转RGB
            img_data = np.repeat(img_data, 3, axis=0)
            print(f"转换为3通道图像")
        elif img_data.shape[0] == 3 and expected_channels == 1:
            # RGB转灰度
            img_data = np.mean(img_data, axis=0, keepdims=True)
            print(f"转换为单通道图像")
        elif img_data.shape[0] == 3 and expected_channels == 4:
            # 为3波段图像添加空波段以适配4波段模型
            # 创建一个与原图像形状相同的零数组，但增加一个波段
            empty_band = np.zeros((1, img_data.shape[1], img_data.shape[2]), dtype=img_data.dtype)
            # 将原图像和空波段连接
            img_data = np.concatenate([img_data, empty_band], axis=0)
            print(f"为3波段图像添加空波段，转换为4通道图像")
        elif img_data.shape[0] > expected_channels:
            # 裁剪多余通道
            img_data = img_data[:expected_channels]
            print(f"裁剪到{expected_channels}通道")
        else:
            print(f"无法处理通道数不匹配，跳过...")
            return

    print(f"Original image shape: {img_data.shape}")

    # 保存原始数据用于反归一化
    original_img_data = img_data.copy()

    # 图像预处理 - 归一化到[0,1]
    img_normalized = normalize_image(img_data.astype(np.float32))

    # 转换为PyTorch张量
    img_tensor = torch.from_numpy(img_normalized).float().unsqueeze(0)
    img_tensor = img_tensor.to(device)

    print(f"Input tensor shape: {img_tensor.shape}")
    print(f"Input tensor device: {img_tensor.device}")

    with torch.no_grad():
        # 模型推理
        print("Running inference...")
        output = model(img_tensor).data.squeeze().float().cpu().numpy()
        print(f"Output tensor shape: {output.shape}")
        print("Inference completed successfully!")

    # 确保输出在[0,1]范围内
    output = np.clip(output, 0, 1)
    print(f"Output data range after clipping: min={np.min(output):.4f}, max={np.max(output):.4f}")

    # 反归一化到原始数据范围
    output_denormalized = denormalize_image(output, original_img_data)
    print(f"Denormalized output range: min={np.min(output_denormalized):.4f}, max={np.max(output_denormalized):.4f}")
    print(f"Denormalized output type: {output_denormalized.dtype}")

    # 保存结果
    input_name = os.path.splitext(os.path.basename(args.input))[0]
    output_path = os.path.join(args.output, f'{input_name}_sr.tif')
    save_tif_with_gdal(output_denormalized, output_path, geotransform, projection, scale_factor=args.scale)

    print(f"超分辨率图像已保存到: {output_path}")


if __name__ == '__main__':
    main()