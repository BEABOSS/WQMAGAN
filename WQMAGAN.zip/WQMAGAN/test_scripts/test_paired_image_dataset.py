# 

import math
import os
import torch
from osgeo import gdal
import numpy as np
from basicsr.data import build_dataloader, build_dataset


def save_tensor_as_tif(tensor, filename, dtype=gdal.GDT_UInt16):
    """
    将 [C, H, W] 的 torch.Tensor 保存为 TIF 图像
    支持 4 通道遥感图像（如多光谱）
    """
    if hasattr(tensor, 'detach'):
        tensor = tensor.detach().cpu().numpy()
    if tensor.ndim != 3:
        raise ValueError("输入 tensor 必须是 [C, H, W]")
    
    c, h, w = tensor.shape

    # 创建 TIF 文件
    driver = gdal.GetDriverByName("GTiff")
    dataset = driver.Create(filename, w, h, c, dtype)

    for i in range(c):
        band = dataset.GetRasterBand(i + 1)
        band.WriteArray(tensor[i, :, :])
    
    dataset.FlushCache()
    dataset = None


def main(mode='folder'):
    """测试 PairedImageDataset 的四波段遥感影像读取和保存."""

    # 配置 Dataset 加载参数
    opt = {}
    opt['dist'] = False
    opt['phase'] = 'train'
    opt['name'] = 'RS4Bands'
    opt['type'] = 'PairedImageDataset'

    if mode == 'folder':
        opt['dataroot_gt'] = 'datasets/YourDataset/GT'  # 替换为你的 HR 路径
        opt['dataroot_lq'] = 'datasets/YourDataset/LQ'  # 替换为你的 LR 路径
        opt['filename_tmpl'] = '{}'
        opt['io_backend'] = dict(type='disk')
    elif mode == 'meta_info_file':
        opt['dataroot_gt'] = 'datasets/YourDataset/GT'
        opt['dataroot_lq'] = 'datasets/YourDataset/LQ'
        opt['meta_info_file'] = 'basicsr/data/meta_info/your_meta_info.txt'
        opt['filename_tmpl'] = '{}'
        opt['io_backend'] = dict(type='disk')
    elif mode == 'lmdb':
        opt['dataroot_gt'] = 'datasets/YourDataset/GT.lmdb'
        opt['dataroot_lq'] = 'datasets/YourDataset/LQ.lmdb'
        opt['io_backend'] = dict(type='lmdb')

    # 数据增强、加载器参数
    opt['gt_size'] = 128
    opt['use_hflip'] = True
    opt['use_rot'] = True
    opt['num_worker_per_gpu'] = 2
    opt['batch_size_per_gpu'] = 4
    opt['scale'] = 4
    opt['dataset_enlarge_ratio'] = 1

    os.makedirs('tmp', exist_ok=True)

    # 构建数据集和加载器
    dataset = build_dataset(opt)
    data_loader = build_dataloader(dataset, opt, num_gpu=0, dist=opt['dist'], sampler=None)

    print('开始读取并保存 .tif 图像...')
    for i, data in enumerate(data_loader):
        if i >= 5:  # 控制测试数量
            break
        print(f'Batch {i}')

        lq = data['lq']  # 低分辨率图像 Tensor: [B, C, H, W]
        gt = data['gt']  # 高分辨率图像 Tensor: [B, C, H, W]
        lq_paths = data['lq_path']
        gt_paths = data['gt_path']

        for b in range(lq.shape[0]):
            # 从路径中提取文件名（无扩展名）
            base_name = os.path.splitext(os.path.basename(gt_paths[b]))[0]

            # 保存为 TIF 图像
            save_tensor_as_tif(lq[b], f'tmp/lq_{base_name}.tif', dtype=gdal.GDT_UInt16)
            save_tensor_as_tif(gt[b], f'tmp/gt_{base_name}.tif', dtype=gdal.GDT_UInt16)

            print(f"保存: tmp/lq_{base_name}.tif 和 tmp/gt_{base_name}.tif")


if __name__ == '__main__':
    main()
